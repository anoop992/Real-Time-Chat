def global_val():

    client_id_val               = "2abd6204-d720-423c-adc2-d861b31246b0"  
    client_secret_val           = "oOW8Q~EGHo~i097KltkD4TyXE.Vvs2Kn9yeOycUC"
    tenant_id_val               = "ca193ac9-bff8-4111-b674-dcbf7984e31c"
    purview_account_name_val    = "purview-pov-dev"

    grant_type_val              = "client_credentials"
    resource_url_val            = "https://purview.azure.net/"    


    stroy_end_point_url_val     = "https://ea-dev-apim.azure-api.net/sac/v1/stories"
    resource_end_point_url_val  = "https://ea-dev-apim.azure-api.net/sac/v1/content" 
    unique_token_val            = "7a12b0983580410f923100a7a0529b19"

    #logger path 
    log_path = "C:/Users/devpurview/Documents/Flowers_Foods_SAC_PURVIEW/SAC_LOG/Logger.txt"


    application_global_values= {"client_id":client_id_val,"client_secret":client_secret_val,"tenant_id":tenant_id_val,"grant_type":grant_type_val,"resource_url":resource_url_val,
    "purview_account_name":purview_account_name_val,"stroy_end_point_url":stroy_end_point_url_val,"resource_end_point_url":resource_end_point_url_val,"unique_token":unique_token_val,"log_path":log_path}
    return application_global_values
