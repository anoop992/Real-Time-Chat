"""
Author/File Name   : Xoriant team / sap_purview_ff_script.py
Project Description: Pull data from SAP endpoint and import in Purview entity
Deployement method : Job-Scheduler ()
Git repo           :
"""

##### Required Packages - Support ######
from configparser import ConfigParser
import requests
import json
import pandas as pd
import datetime

############### Azure packages ######
from azure.identity import ClientSecretCredential
from purviewautomation import PurviewCollections, ServicePrincipalAuthentication

############### atlas ####################

from pyapacheatlas.auth import ServicePrincipalAuthentication
from pyapacheatlas.core import PurviewClient, AtlasEntity, AtlasProcess, TypeCategory
from pyapacheatlas.core.util import GuidTracker
from pyapacheatlas.core.typedef import AtlasAttributeDef, EntityTypeDef, RelationshipTypeDef

# Config -  Setting 

#CONFIG_OBJ = ConfigParser()
#CONFIG_OBJ.read("./config.ini")

log_file= open("./DDP-Platform/Logger.txt","w+")
task_start = datetime.datetime.now()
log_file.write("Task start time {}\n".format(str(task_start)))



#Global varible declaration

client_id               = "2abd6204-d720-423c-adc2-d861b31246b0"
client_secret           = "oOW8Q~EGHo~i097KltkD4TyXE.Vvs2Kn9yeOycUC"
grant_type              = 'client_credentials'
resource_url            = "https://purview.azure.net/"
tenant_id               = "ca193ac9-bff8-4111-b674-dcbf7984e31c"
purview_account_name    = "purview-pov-dev"


# client_id               = CONFIG_OBJ["SAP_TOKEN"]['client_id']
# client_secret           = CONFIG_OBJ["SAP_TOKEN"]['client_secret']
# grant_type              = 'client_credentials'
# resource_url            = CONFIG_OBJ["SAP_TOKEN"]['resource']
# tenant_id               = CONFIG_OBJ["SAP_TOKEN"]['tenant_id']
# purview_account_name    = "purview-pov-dev"

### Atlas packages to connect to purview

oauth   = ServicePrincipalAuthentication(tenant_id=tenant_id,client_id=client_id,client_secret=client_secret)
client  = PurviewClient(account_name = purview_account_name,authentication=oauth)

### SAP end-pt global variable

# stroy_end_point_url     = CONFIG_OBJ["SAP_ENDPOINT"]['stories_end_point']
# resource_end_point_url  = CONFIG_OBJ["SAP_ENDPOINT"]['resource_end_point']
# unique_token            = CONFIG_OBJ["SAP_TOKEN"]['token']

stroy_end_point_url     = "https://ea-dev-apim.azure-api.net/sac/v1/stories"
resource_end_point_url  = "https://ea-dev-apim.azure-api.net/sac/v1/content"
unique_token            = "7a12b0983580410f923100a7a0529b19"



## Remove enetity name
remove_qualified_name   = ["pyapacheatlas://sac_stories_clutser", "pyapacheatlas://sac_stories"]
remove_entity_type_name = "SAC_API"    

sap_end_pt_flag         = 0
sap_end_pt_value_flag   = 1

remove_flag             = 0


unit_test=1
"""
fucntion to call spa-endpoint 
"""

class spa_end_pt_fetch_import_purview:
    
    def __init__(self,):
        self.story_url      = stroy_end_point_url
        self.resource_url   = resource_end_point_url
        self.unique_token   = unique_token
        self.remove_flag    = 0
    # Connect to SPA - API
    def end_pt_data(self,):

        """
        Connect to SPA end point and fetch data of stories and resource data
        Args:
            request: Token & URL path 
        Return:
            Json data of stories and resource
        """

        try:
            headers = {'Ocp-Apim-Subscription-Key': self.unique_token}
            stroy_end_pt_json=(requests.get(self.story_url, headers=headers))
            resource_end_pt_json=(requests.get(self.resource_url, headers=headers))
            stories_df = pd.DataFrame.from_dict(stroy_end_pt_json.json())
            #resource_df = pd.DataFrame.from_dict(resource_end_pt_json.json())
            log_file.write(("SAC-Fetch- -> Dataframe\n"))
            log_file.write("{}\n".format(str(stories_df)))
            log_file.write(("SAC-Fetch- -> Completed\n"))

            sap_end_pt_flag=1
        except Exception as e:
            # Error Report append
            sap_end_pt_flag=2
            log_file.write(("SAC-Fetch Error - -> {}\n".format(e)))

        finally:                        
            
            return stories_df,sap_end_pt_flag
    
    # Remove the data in entity
    def remove_entity_data_purview(self,entity_ty_name,entity_qulified_name):
        """
        Connect to Purview import new data in entity
        Args:
        
            request: @param entity_ty_name,entity_qulified_name.
        Return:
            remove_flag - First load entity shows msg because no entity was created previous 
        """

        try:
            # invoke the entities to remove
            entities = client.get_entity(qualifiedName=entity_qulified_name,typeName=entity_ty_name)

            # remove all the enetity under SAP_API
            for entity in entities.get("entities"):
                guids = entity["guid"]
                delete_response = client.delete_entity(guid=guids)
            self.remove_flag = 1

        except Exception as e:
            self.remove_flag = 2
            log_file.write(("Entity Created in Purview\n"))
        finally:
            
            return self.remove_flag
    
    #import sap end pt data in purview entity

    def import_data_purview(self,st_df,resourc_val):

        """
        Create entity and custome properties along with data relation and entity releation 
        Args:
        
            request: @param st_df,resourc_df
        Return:
            logg msg status - return the log msg  
        """
        try:
            # unique id tracker
            guid = GuidTracker()
            
            atlas_input_df_columns = [] # empty list declar to append entity job and colums
            
            #Dataframe enetity
            type_sap_df = EntityTypeDef(name="SAC_API",
                                        attributeDefs=[AtlasAttributeDef(name="format"),],
                                        superTypes = ["DataSet"],
                                        options = {"schemaElementAttribute":"columns"})
            
            # Custome properties columns
            type_sap_columns = EntityTypeDef(name="SAC_AC_SCHEMA",attributeDefs=[AtlasAttributeDef(name="data_type"),
                                                                                     AtlasAttributeDef(name="createdBy"),
                                                                                     AtlasAttributeDef(name="id"),
                                                                                     AtlasAttributeDef(name="created")],
                                                                                     superTypes = ["DataSet"],)
            # Job creation for the SAC_API - LIN
            """
            @@@@@@@
            type_sap_job = EntityTypeDef(name="SAC_API_JOB",
                                         attributeDefs=[AtlasAttributeDef(name="job_type",isOptional=False),
                                                        AtlasAttributeDef(name="schedule",defaultValue="adHoc")],
                                                                             superTypes = ["Process"])
            @@@@@
            """
            # Schema creation  SAC_AC_SCHEMA in SAP_API Job Relation
            sap_column_to_df_relationship = RelationshipTypeDef(name="SAC_API_COMPOSE",
                                                                  relationshipCategory="COMPOSITION",
                                                                  endDef1={"type": "SAC_API",
                                                                           "name": "columns",
                                                                           "isContainer": True,
                                                                           "cardinality": "SET",
                                                                           "isLegacyAttribute": False},
                                                                           endDef2={"type": "SAC_AC_SCHEMA",
                                                                                    "name": "dataframe",
                                                                                    "isContainer": False,
                                                                                    "cardinality": "SINGLE",
                                                                                    "isLegacyAttribute": False})
            #Upload all the jobs in SAP_API entity

            # typedef_results = client.upload_typedefs(entityDefs =[type_sap_df, 
            #                                                       type_sap_columns, 
            #                                                       type_sap_job ],
            #                                                       relationshipDefs = [sap_column_to_df_relationship],
            #                                                       force_update=True)
            typedef_results = client.upload_typedefs(entityDefs =[type_sap_df, 
                                                                  type_sap_columns 
                                                                  ],
                                                                  relationshipDefs = [sap_column_to_df_relationship],
                                                                  force_update=True)
            log_file.write(("Schema Created in Purview\n"))
                       
            #Upload all the jobs in SAP_API entity
            atlas_input_df = AtlasEntity(name="sac_stories",
                                         qualified_name = remove_qualified_name[1],
                                         typeName="SAC_API",guid=guid.get_guid(),
                                         description="SAC-Stories Data",
                                         attributes = {"name":"test"},)
            """
            @@@@@@@@@@@
            process = AtlasProcess(name="SAC_Stories_clutser",
                                   qualified_name = remove_qualified_name[0],
                                   typeName="SAC_API_JOB",
                                   guid=guid.get_guid(),
                                   attributes = {"job_type":"sac_stories_clutser"},
                                   inputs = [atlas_input_df],outputs = [])
            
            @@@@@
            """
            #import all the rows of columns in SPA_API entity
            for i in st_df.index:
                if unit_test==1:
                    temp_column = AtlasEntity(name = st_df['name'][i],
                                              typeName = "SAC_AC_SCHEMA",
                                              qualified_name = st_df['openURL'][i],
                                              guid=guid.get_guid(),
                                              attributes = {"description":str(st_df['description'][i]),"displayName":str(st_df['name'][i]),
                                                            'data_type':str(st_df['description'].dtype),"id":str(st_df['id'][i]),"createdBy":str(st_df['createdBy'][i]),
                                                            "created":str(st_df['created'][i])},relationshipAttributes = {"dataframe":atlas_input_df.to_json(minimum=True)})
                    atlas_input_df_columns.append(temp_column) # upload all the columns rows in the empty list

            #batch = [process, atlas_input_df] + atlas_input_df_columns ## List of
            batch = [atlas_input_df] + atlas_input_df_columns ## List of

            client.upload_entities(batch=batch)

            

        except Exception as e:
            log_file.write(("Error Occur Purview Load --> {}\n".format(e)))
        finally:
            task_start = datetime.datetime.now()
            log_file.write("Task Completed successfully {}\n".format(str(task_start)))


### Trigger the Script to Run ####:

if __name__ == '__main__':
    trigger_cls = spa_end_pt_fetch_import_purview()
    stor_data_df,flag_end_pt = trigger_cls.end_pt_data()
    

    #call a function to remove columns entity
    if flag_end_pt ==1:
        remove_flag_data = trigger_cls.remove_entity_data_purview(remove_entity_type_name,remove_qualified_name)
    
    #import endpoint updated data in entity
    if len(stor_data_df) !=0 and flag_end_pt ==1:
        resour_data_df=0
        import_status = trigger_cls.import_data_purview(stor_data_df,resour_data_df)
        



