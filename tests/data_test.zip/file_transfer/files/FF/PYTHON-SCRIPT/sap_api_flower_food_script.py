"""
Author/File Name   : Xoriant team / sap_api_flower_food.py
Project Description: Import SAP Data in Azure Purview
Deployement method :
Git repo           :
"""
from configparser import ConfigParser
import requests
import json
import base64
from requests.models import RequestEncodingMixin
import pandas as pd
import urllib.request, json
################################## Azure packages ##############################
from azure.purview.scanning import PurviewScanningClient
from azure.purview.catalog import PurviewCatalogClient
from azure.purview.administration.account import PurviewAccountClient
from azure.identity import ClientSecretCredential 
from azure.core.exceptions import HttpResponseError

################################## Azure packages for register the data source ##############################

from azure.purview.administration.account import PurviewAccountClient
from azure.purview.scanning import PurviewScanningClient
from azure.core.exceptions import HttpResponseError
from azure.identity import ClientSecretCredential
from purviewautomation import PurviewCollections, ServicePrincipalAuthentication


############### atlas ####################

from pyapacheatlas.auth import ServicePrincipalAuthentication
from pyapacheatlas.core import PurviewClient, AtlasEntity, AtlasProcess, TypeCategory
from pyapacheatlas.core.util import GuidTracker
from pyapacheatlas.core.typedef import AtlasAttributeDef, EntityTypeDef, RelationshipTypeDef


#setup config file 
CONFIG_OBJ = ConfigParser()
CONFIG_OBJ.read("./config.ini")

client_id = CONFIG_OBJ["SAP_TOKEN"]['client_id']
client_secret = CONFIG_OBJ["SAP_TOKEN"]['client_secret']
grant_type = 'client_credentials'
resource_url = CONFIG_OBJ["SAP_TOKEN"]['resource']
tenant_id = CONFIG_OBJ["SAP_TOKEN"]['tenant_id']

############## atlas start ###############
#https://login.microsoftonline.com/d870244a-9053-483e-9a46-0597932f0a73/oauth2/token

url = CONFIG_OBJ["SAP_TOKEN"]['url_purview']
header_data = {'Content-Type':'application/x-www-form-urlencoded'}
datas={
    'client_id':CONFIG_OBJ["SAP_TOKEN"]['client_id'],
    'client_secret':CONFIG_OBJ["SAP_TOKEN"]['client_secret'],
    'grant_type':'client_credentials'
}

##################### SAP PYTHON #######################


# try:
#     url = "https://ea-dev-apim.azure-api.net/sac/v1/Resources"

#     hdr ={
#     # Request headers
#     'Cache-Control': 'no-cache',
#     'Ocp-Apim-Subscription-Key': '3f6936912f0540b4b60a227e9491dbdd',
#     }

#     req = urllib.request.Request(url, headers=hdr)

#     req.get_method = lambda: 'GET'
#     response = urllib.request.urlopen(req)
#     print(response.getcode())
#     print(response.read())
# except Exception as e:
#     print(e)
# exit()
######################## END SAP ########
atoken=(requests.get(url, headers=header_data, data=datas))
# print(atoken)
# ac = atoken.json()
# print(ac)

# auth = ServicePrincipalAuthentication(client_id=CONFIG_OBJ["SAP_TOKEN"]['client_id'], client_secret=CONFIG_OBJ["SAP_TOKEN"]['client_secret'], tenant_id=CONFIG_OBJ["SAP_TOKEN"]['tenant_id'])
# clirnt =PurviewCollections('msflowerfoodpoc',auth)
# sss = clirnt.list_collections(pprint=True)
# print(sss)
# exit()

oauth = ServicePrincipalAuthentication(tenant_id=tenant_id,client_id=client_id,client_secret=client_secret)
client = PurviewClient(account_name = "purview-pov-dev",authentication=oauth)




# sss = client.list_collections(pprint=True)
# print(sss)
# exit()

# auth = ServicePrincipalAuthentication(client_id=CONFIG_OBJ["SAP_TOKEN"]['client_id'], client_secret=CONFIG_OBJ["SAP_TOKEN"]['client_secret'], tenant_id=CONFIG_OBJ["SAP_TOKEN"]['tenant_id'])
# clirnt =PurviewCollections('msflowerfoodpoc',auth)
# sss = clirnt.list_collections(pprint=True)
# print(sss)
"""
Secret Value
oOW8Q~EGHo~i097KltkD4TyXE.Vvs2Kn9yeOycUC

Secret ID
6da571ac-2699-4c15-afdf-d1d5dd06c5e0

Tenant ID
ca193ac9-bff8-4111-b674-dcbf7984e31c

ClientID
2abd6204-d720-423c-adc2-d861b31246b0

Name: purview-pov-dev


"""

# response = client.delete_entity(guid="d870244a-9053-483e-9a46-0597932f0a73")
# print(json.dumps(response, indent=2))
# exit()
#global:
unit_test_id = 1
stroy_end_point_url = CONFIG_OBJ["SAP_ENDPOINT"]['stories_end_point']
content_end_point_url = CONFIG_OBJ["SAP_ENDPOINT"]['content_end_point']
unique_token = CONFIG_OBJ["SAP_TOKEN"]['token']

headers = {'Ocp-Apim-Subscription-Key': unique_token}
stroy_end_pt_json=(requests.get(stroy_end_point_url, headers=headers))

notebook_path ='_data'

"""
entities = client.get_entity(
      qualifiedName=["pyapacheatlas://sac_stories"],
      typeName="SAC_API"
  )

for entity in entities.get("entities"):
    guids = entity["guid"]
    print(guids)
    delete_response = client.delete_entity(guid=guids)
print('1')
exit()

entities = client.get_entity(
      qualifiedName=["pyapacheatlas://sac_stories_clutser"],
      typeName="SAC_API_JOB"
  )

for entity in entities.get("entities"):
    guids = entity["guid"]
    print(guids)
    delete_response = client.delete_entity(guid=guids)
print('1')
exit()
"""

# client.delete_entity("SAP_API_COMPOSE")
# exit()
"""
#SAP_API_COMPOSE
batch_dele = ['SAP_API_COLUMNS']
for i in batch_dele:
  client.delete_entity(guid=i)

exit()
"""


# When you need to find multiple Guids to kalayan and they all
    # are the same type kalayan

entities = client.get_entity(
      qualifiedName=["/sap/fpa/ui/tenants/d874e/bo/story/6D5AD458FB46D149E10000007F000101"],
      #qualifiedName=["/sap/fpa/ui/tenants/d874e/bo/story/583E3CAA216A0569E10000000AA513C9"],
      #qualifiedName=["/sap/fpa/ui/tenants/d874e/bo/story/583E3BE2216A0569E10000000AA513C9"],
      #qualifiedName=["/sap/fpa/ui/tenants/d874e/bo/story/583E39BB216A0569E10000000AA513C9"],
      #qualifiedName=["/sap/fpa/ui/tenants/d874e/bo/story/583E3817216A0569E10000000AA513C9"],
      #qualifiedName=["/sap/fpa/ui/tenants/d874e/bo/story/7E0050581E24D39CE10000000A784278"],
      #qualifiedName=["/sap/fpa/ui/tenants/d874e/bo/story/583E3B02216A0569E10000000AA513C9"],
      typeName="SAC_AC_SCHEMA"
  )
for entity in entities.get("entities"):
      guids = entity["guid"]
      print(guids)
      delete_response = client.delete_entity(guid=guids)
exit()


# for entity in entities.get("entities"):
#     guids = entity["guid"]
#     print(guids)
#     delete_response = client.delete_entity(guid=guids)
# print(11122)
# exit()


try:  
  
  entities = client.get_entity(
      qualifiedName=["pyapacheatlas://story_data"],
      typeName="SAP_API"
  )

  for entity in entities.get("entities"):
      guids = entity["guid"]
      print(guids)
      delete_response = client.delete_entity(guid=guids)
  

  entities = client.get_entity(
      qualifiedName=["pyapacheatlas://stories_clutser_data"],
      typeName="SAP_AC_API"
  )

  for entity in entities.get("entities"):
      guids = entity["guid"]
      print(guids)
      delete_response = client.delete_entity(guid=guids)
  
      print(json.dumps(delete_response, indent=2))
  
except Exception as e:
    pass
    #print('False',e)
finally:
  guid = GuidTracker()
print(222)

exit()
  # oauth = ServicePrincipalAuthentication(tenant_id=tenant_id,client_id=client_id,client_secret=client_secret)
  # client = PurviewClient(account_name = "msflowerfoodpoc",authentication=oauth)

#guid = GuidTracker()

#demo_clusterTESTTT
#demo_dbfs_delays_data
#custom_spark_dataframe_column


#df = pd.DataFrame(stroy_end_pt_json.json())
df = pd.DataFrame.from_dict(stroy_end_pt_json.json())

#df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'story_end_pt_data.csv',index=False)
#exit()
loop_count_val = (len(stroy_end_pt_json.json()))


####################### DELETE ENTITY ################################
# batch_dele = ['SAP_API_JOB','SAP_API','SAP_API_COLUMNS']
# for i in batch_dele:
#     client.delete_entity(guid=i) 
# exit()
# client.delete_entity(guid=batch) 

# Create an asset for the input data frame.
#print(loop_count_val)
#exit()
"""
list_entity = []
for v_name in range(loop_count_val):
    q = stroy_end_pt_json.json()[v_name]['name']

    globals()[f"atlas_input_df {q}"] = AtlasEntity(
        name=stroy_end_pt_json.json()[v_name]['name'],
        qualified_name = "pyapacheatlas://"+ stroy_end_pt_json.json()[v_name]['name'],
        typeName="stories",
        guid=guid.get_guid(),
        description=stroy_end_pt_json.json()[v_name]['description']
        )
    
    list_entity.append(atlas_input_df)

    #print(q)
    #globals()[f"test {q}"] = 'test{}'.format(v_name)

print(atlas_input_df1)
#print(len(stroy_end_pt_json.json()[0]))
exit()

"""
###########################################################
# Set up a few types and relationships
# This is a one time thing but necessary to make the demo work
# It also demonstrates how you can capture different attributes
# for your dataframes, dataframe columns, and jobs.


type_spark_df = EntityTypeDef(
  name="SAP_API",
  attributeDefs=[
    AtlasAttributeDef(name="format"),
    
  ],
  superTypes = ["DataSet"],
  options = {"schemaElementAttribute":"columns"}
 )

print(11)
type_spark_columns = EntityTypeDef(
  name="SAP_API_COLUMNS",
  attributeDefs=[
    AtlasAttributeDef(name="data_type"),
    AtlasAttributeDef(name="createdBy"),
    AtlasAttributeDef(name="id"),
    #AtlasAttributeDef(name="changedBy"),
    AtlasAttributeDef(name="created")    
  ],
  superTypes = ["DataSet"],
)
print(12)

type_spark_job = EntityTypeDef(
  name="SAP_API_JOB",
  attributeDefs=[
    AtlasAttributeDef(name="job_type",isOptional=True),
    AtlasAttributeDef(name="schedule",defaultValue="adHoc")
  ],
  superTypes = ["Process"]
)

print(13)
spark_column_to_df_relationship = RelationshipTypeDef(
  name="SAP_API_COMPOSE",
  relationshipCategory="COMPOSITION",
  endDef1={
          "type": "SAP_API",
          "name": "columns",
          "isContainer": True,
          "cardinality": "SET",
          "isLegacyAttribute": False
      },
  endDef2={
          "type": "SAP_API_COLUMNS",
          "name": "dataframe",
          "isContainer": False,
          "cardinality": "SINGLE",
          "isLegacyAttribute": False
      }
)

## Work
# typedef_results = client.delete_typedefs(
#   entityDefs = [type_spark_columns],
#   #entityDefs = [type_spark_df, type_spark_columns, type_spark_job ],
#   #relationshipDefs = [spark_column_to_df_relationship]
#   )
## end


print(14)

#print(typedef_results)
#print(json.dumps(typedef_results,indent=2))
#print(json.dumps(client.get_single_entity(tests),indent=2))


typedef_results = client.upload_typedefs(
  #entityDefs = [type_spark_columns],
  entityDefs = [type_spark_df, type_spark_columns, type_spark_job ],
  #entityDefs = [type_spark_df, type_spark_columns],
  relationshipDefs = [spark_column_to_df_relationship],
  force_update=True)
exit()

# COMMAND ----------

# No we actually do some databricks work

#############################################################
atlas_input_df = AtlasEntity(
  name="story_data",
  qualified_name = "pyapacheatlas://story_data",
  typeName="SAP_API",
  guid=guid.get_guid(),
  description="SAP-Stories datas",
  attributes = {"name":"test"},
)

#print(atlas_input_df.to_json(minimum=True))
#exit()

# Create a process that represents our notebook and has our input
# dataframe as one of the inputs.
process = AtlasProcess(
  name="Stories_clutser"+notebook_path,
  qualified_name = "pyapacheatlas://stories_clutser"+notebook_path,
  typeName="SAP_API_JOB",
  guid=guid.get_guid(),
  attributes = {"job_type":"stories_sap_data"},
  inputs = [atlas_input_df],
  outputs = [] # No outputs for this demo, but otherwise, repeat what you did you the input dataframe.
)



# When you need to find multiple Guids to delete and they all
# are the same type DELETED

# Iterate over the input data frame's columns and create them.
# Note: This is an add, not a delete. If the dataframe already exists in
# Atlas/Data Catalog, this sample is not smart enough to prune any 'orphan'
# columns. They will continue to exist and point to the dataframe.
atlas_input_df_columns = []
# for column in df:
#     print(df[column].dtypes)
# exit()

# for i in df.index:
#     #print(df['name'][i])
#     print (df['openURL'].dtype)

# exit()
k=1
for i in df.index:
    
    #attributes_dict = {"description":(df['description'][i]),'createdBy':(df['createdBy'][i]),
    #                    'id':(df['id'][i]),'changed':(df['changed'][i]),'changedBy':(df['changedBy'][i])}
    #print(attributes_dict)
    #exit()
    if i < 3:
        print(i,"###########",df['name'][i])
        temp_column = AtlasEntity(
        name = df['name'][i],
        typeName = "SAP_API_COLUMNS",
        qualified_name = df['openURL'][i],
        guid=guid.get_guid(),
        attributes = {"description":str(df['description'][i]),"displayName":str(df['name'][i]),
                    'data_type':str(df['description'].dtype),"created":str(df['created'][i])},
        #attributes = {"data_type":str("ss")},
        relationshipAttributes = {"dataframe":atlas_input_df.to_json(minimum=True)}
        )
        atlas_input_df_columns.append(temp_column)

# COMMAND ----------

print("###### process ###",process)
print("###### atlas_input_df ###",atlas_input_df)
print("###### atlas_input_df_columns ###",atlas_input_df_columns)
# Prepare all the entities as a batch to be uploaded.
batch = [process, atlas_input_df] + atlas_input_df_columns
#batch_dele = ['SAP_API_JOB','SAP_API','SAP_API_COLUMNS']
# COMMAND ----------

# Upload all entities!

#print(json.dumps(client.get_single_entity(guid),indent=2))


client.upload_entities(batch=batch)

#client.delete_entity(batch=batch)







print("completed")
exit()
for i in stroy_end_pt_json.json():
    print(i)
exit()
#print(stroy_end_point_url.split('/')[-1])

gt = GuidTracker()

#####################

# Set up a few types and relationships
# This is a one time thing but necessary to make the demo work
# It also demonstrates how you can capture different attributes
# for your dataframes, dataframe columns, and jobs.
"""
type_spark_df = EntityTypeDef(
  name="custom_spark_dataframe",
  attributeDefs=[
    AtlasAttributeDef(name="format")
  ],
  superTypes = ["DataSet"],
  options = {"schemaElementAttribute":"columns"}
 )
type_spark_columns = EntityTypeDef(
  name="custom_spark_dataframe_column",
  attributeDefs=[
    AtlasAttributeDef(name="data_type")
  ],
  superTypes = ["DataSet"],
)
type_spark_job = EntityTypeDef(
  name="custom_spark_job_process",
  attributeDefs=[
    AtlasAttributeDef(name="job_type",isOptional=False),
    AtlasAttributeDef(name="schedule",defaultValue="adHoc")
  ],
  superTypes = ["Process"]
)

spark_column_to_df_relationship = RelationshipTypeDef(
  name="custom_spark_dataframe_to_columns",
  relationshipCategory="COMPOSITION",
  endDef1={
          "type": "custom_spark_dataframe",
          "name": "columns",
          "isContainer": True,
          "cardinality": "SET",
          "isLegacyAttribute": False
      },
  endDef2={
          "type": "custom_spark_dataframe_column",
          "name": "dataframe",
          "isContainer": False,
          "cardinality": "SINGLE",
          "isLegacyAttribute": False
      }
)

typedef_results = client.upload_typedefs(
  entityDefs = [type_spark_df, type_spark_columns, type_spark_job ],
  relationshipDefs = [spark_column_to_df_relationship],
  force_update=True)
print(typedef_results)
"""

#####################
exit()
column_entity_def = EntityTypeDef(
            name='stories11',
            superTypes=["DataSet"],
            attributeDefs=[
                AtlasAttributeDef("data_type", typeName="string", isOptional=False)
                ]
            )

table_entity_def = EntityTypeDef(
        #name=stroy_end_point_url.split('/')[-1],
        name='SAP_demo_table',
        superTypes=["DataSet"],
        relationshipAttributeDefs=[],
        # This option "schemaElementsAttribute" is the secret to getting a
        # particular relationship attribute's entities displayed in the 
        # schema UI.
        options={"schemaElementsAttribute": "columns"}
    )

table_column_relationship = RelationshipTypeDef(
        name="storyies",
        relationshipCategory="COMPOSITION",
        endDef1={
            "type": table_entity_def.name,
            "name": "columns",
            "isContainer": True,
            "cardinality": "SET",
            "isLegacyAttribute": False,
        },
        endDef2={
            "type": column_entity_def.name,
            "name": "table",
            "isContainer": False,
            "cardinality": "SINGLE",
            "isLegacyAttribute": False
        }
    )
typedef_results = client.upload_typedefs(
  entityDefs = [column_entity_def, table_entity_def],
  relationshipDefs = [table_column_relationship],
  force_update=True)
print(typedef_results)

exit("@@@")
def createEntities(columns_list,dataset):
    result =[AtlasEntity(name = column['name'],typeName ="SAP_demo_column",qualified_name=f"pyapacheatlas://demo_dbfs_delays_data://{dataset}@{column['name']}",attributes = {'createdBy':column['createdBy'],'description':column['description']},guid =gt.get_guid())  for column in columns_list]
    
    return result
em=[]
for i in stroy_end_pt_json.json():
    for k in i.keys():
        em.clear()
        em.append(i)
        
        table_entity = AtlasEntity(
        name=k,
        qualified_name=f"pyapacheatlas://demo_dbfs_delays_data#"+k,
        typeName="SAP_demo_table",
        guid=gt.get_guid())
        result = createEntities(em,stroy_end_point_url.split('/')[-1])

        for columnEntity in result:
            columnEntity.addRelationship(table = table_entity)
        result.append(table_entity)

        upload_results = client.upload_entities(
        batch=result)
        print(json.dumps(upload_results, indent=2))
exit()

"""
for dataset in dataset_schema.keys():
        table_entity = AtlasEntity(
        name=dataset,
        qualified_name=f"SAP://{dataset}",
        typeName="SAP_demo_table",
        guid=gt.get_guid())
        result = createEntities(dataset_schema[dataset],dataset)
        for columnEntity in result:
            columnEntity.addRelationship(table = table_entity)
        result.append(table_entity)
           
        upload_results = client.upload_entities(
        batch=result)
        print(json.dumps(upload_results, indent=2))
        """

#sss = clirnt.list_collections(pprint=True)
#print(client.collections(pprint=True))
exit()


story_point = ['name','description','createdBy','id','created','changed','isTemplate','isSample','changedBy','openURL']




############### altals end
#########
"""

"""
# Access token
####"""
url = CONFIG_OBJ["SAP_TOKEN"]['url_purview']
header_data = {'Content-Type':'application/x-www-form-urlencoded'}
datas={
    'client_id':CONFIG_OBJ["SAP_TOKEN"]['client_id'],
    'client_secret':CONFIG_OBJ["SAP_TOKEN"]['client_secret'],
    'grant_type':'client_credentials'

}

# atoken=(requests.get(url, headers=header_data, data=datas))
# print(atoken)
# ac = atoken.json()
# print(ac)
# exit()

###"""

auth = ServicePrincipalAuthentication(client_id=CONFIG_OBJ["SAP_TOKEN"]['client_id'], client_secret=CONFIG_OBJ["SAP_TOKEN"]['client_secret'], tenant_id=CONFIG_OBJ["SAP_TOKEN"]['tenant_id'])
clirnt =PurviewCollections('msflowerfoodpoc',auth)
sss = clirnt.list_collections(pprint=True)
print(sss)



#global:
unit_test_id = 1
stroy_end_point_url = CONFIG_OBJ["SAP_ENDPOINT"]['stories_end_point']
content_end_point_url = CONFIG_OBJ["SAP_ENDPOINT"]['content_end_point']
unique_token = CONFIG_OBJ["SAP_TOKEN"]['token']

"""
Script to ftech SAP Endpoint responce 
"""
class sap_api_call():
    def __init__(self):
        pass

    def request_api_call(self,):
        try:        
            headers = {'Ocp-Apim-Subscription-Key': unique_token}
            stroy_end_pt_json=(requests.get(stroy_end_point_url, headers=headers))            

        except Exception as e:

            print(e)

        finally:

            print(stroy_end_pt_json.json())


class Azure_purview_flow():

    def __init__(self):
        self.credentials = ClientSecretCredential(client_id=CONFIG_OBJ["SAP_TOKEN"]['client_id'], client_secret=CONFIG_OBJ["SAP_TOKEN"]['client_secret'], tenant_id=CONFIG_OBJ["SAP_TOKEN"]['tenant_id'])
        #pass
        
    
    """
    Desc: Funtion to Register a data source
    Args: Pass the json key values
    return: True or False - based on the success 
    """
    def data_source_register(self,):
        try:
            print(self.credentials)

        except Exception as e:

            print(e)

        finally:
            pass

if __name__ == '__main__' and unit_test_id==1:

    #api_call_sap = sap_api_call()
    #api_call_sap.request_api_call()
    api_call_sap = Azure_purview_flow()
    api_call_sap.data_source_register()