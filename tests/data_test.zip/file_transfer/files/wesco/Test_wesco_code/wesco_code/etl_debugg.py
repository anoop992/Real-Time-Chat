"""
Author: Xoriant team
Project Description: ETL Script to import the CSV data in mySQL db using python
Deployement method:
Git repo:
"""
from configparser import ConfigParser
import pandas as pd
import mysql.connector
from sqlalchemy import create_engine
import datetime
import os

#setup config file 
CONFIG_OBJ = ConfigParser()
CONFIG_OBJ.read("./config.ini")


"""
Global config -  varibale to automate load the csv in mysql db
"""
#csv file location
dir_name =CONFIG_OBJ["FILE_PATH"]['file_location']
csv_file_list = [file for file in os.listdir(dir_name)] # List of csv file name in above location
load_count = 0

#db connecttion:
connection_string = CONFIG_OBJ["DB_CONN_LOCAL"]['db_env']
engine = create_engine(connection_string)

mySQL_db = mysql.connector.connect(
  host=CONFIG_OBJ["DB_CONN_LOCAL"]['host_name'],
  user=CONFIG_OBJ["DB_CONN_LOCAL"]['user_name'],
  password=CONFIG_OBJ["DB_CONN_LOCAL"]['password'],
  database=CONFIG_OBJ["DB_CONN_LOCAL"]['db_name']
)

engine.connect()

# Load time cal
process_start_time = datetime.datetime.now()

# custome schema build table name
custome_table_list = CONFIG_OBJ["CUSTOM_SCHEMA"]['table_name']

class etl_load_csv:
    
    def __init__(self,default=0):
        self.default_val = default
        # condition to check for custome_schema 
        if(csv_file_list[default].split('.')[0]) in custome_table_list:
            self.schema_flag = 1
        else:
            self.schema_flag = 23     
    
    def data_insert_mysql(self,):
        """
        Fetch CSV-file and load covert data as dataframe and load in mysql

        Args:
            request: CSV file as a agrs fetch from the location path
        Return:
            Logg message of data table values (toal record value in db and csv file record count)
        """
        try:
            # Count csv file in location and load data in mysql one by one index in list
            global load_count
            load_count += 1
            #read csv file as dataframe
            dataframe = pd.read_csv(dir_name+csv_file_list[self.default_val])
            dataframe["id"] = dataframe.index + 1 #add id as index in dataframe
            # id replace postion as first col in dataframe
            dataframe.set_index(dataframe.columns[-1], inplace=True)
            dataframe.reset_index(inplace=True)

            # lowercase dataframe col name's
            #dataframe.columns = dataframe.columns.str.lower()

            

            #Drop table and load data in mysql table
            if self.schema_flag == 0:
                with engine.begin() as connection:
                    dataframe.to_sql(csv_file_list[self.default_val].split('.')[0], con=connection,
                                     if_exists='replace', index=False)
            else:
                print("----------"'DROPED -TBL Name ',csv_file_list[self.default_val].split('.')[0].lower(),"-----------")
                cursor_conn = mySQL_db.cursor()
                sql_query = "DROP TABLE IF EXISTS {}".format(csv_file_list[self.default_val].split('.')[0].lower())
                #sql_query = "DROP TABLE IF EXISTS mssql_stg_all_objects.csv"
                cursor_conn.execute(sql_query)

            # table load time
            tbl_load_time = datetime.datetime.now()            

            msg_dict = {"record_count":dataframe['id'].count(),'process_start_time':process_start_time,
                        'process_end_time':tbl_load_time,'table_name':csv_file_list[self.default_val].split('.')[0]}

            load_response_message = {'version':'1.0', 'status':'Completed', 'message':msg_dict}
        except Exception as e:

            load_response_message = {'version':'1.0', 'status':'Error', 'message':e,
                                     'table_name':csv_file_list[self.default_val].split('.')[0]}
        finally:

            return load_count,load_response_message

"""
While Condition: This will load all data from csv file's from the location 
Auto load all csv files data in above location 
"""
    
while len(csv_file_list) != load_count and len(csv_file_list) !=0:
    
    exe_ETL = etl_load_csv(load_count)
    result,load_response_message = exe_ETL.data_insert_mysql()
    if len(csv_file_list) == result:
        break
    #print(load_response_message)
    #break
print('Hello-ETL  ------********------  You Completed')
