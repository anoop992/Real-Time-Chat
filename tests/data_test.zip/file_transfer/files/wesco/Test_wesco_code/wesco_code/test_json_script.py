"""
Author/File Name   : Xoriant team / wesco_import_script.py
Project Description: ETL Script to import the CSV data in mySQL db using python
Deployement method :
Git repo           :
"""
from configparser import ConfigParser
import pandas as pd
import mysql.connector
from sqlalchemy import create_engine
import datetime
import os
import json


#setup config file 
CONFIG_OBJ = ConfigParser()
CONFIG_OBJ.read("./config.ini")

"""
Global config -  varibale to automate load the csv in mysql db
"""
#csv file location
dir_name        = CONFIG_OBJ["FILE_PATH"]['file_location']
csv_file_list   = [file for file in os.listdir(dir_name)] # List of csv file name in above location
load_count      = 0
anoop           = 2

#db connecttion:
connection_string   = CONFIG_OBJ["DB_CONN_LOCAL"]['db_env']
engine              = create_engine(connection_string)
engine.connect()

# Load time cal
process_start_time = datetime.datetime.now()
# custome schema build table name
custome_table_list = CONFIG_OBJ["CUSTOM_SCHEMA"]['table_name']

class etl_load_csv:
    
    def __init__(self,default=0):
        self.default_val = default
        # condition to check for custome_schema 
        if(csv_file_list[default].split('.')[0]) in custome_table_list:
            self.schema_flag = 1
        else:
            self.schema_flag = 0    
    
    def data_insert_mysql(self,):
        """
        Fetch CSV-file and covert data as dataframe and load in mysql db
        Args:
            request: CSV file as a agrs fetch from the location path
        Return:
            Logg message of data table values (toal record value in db and csv file record count)
        """
        try:
            # Count csv file in location and load data in mysql one by one index in list
            global load_count
            load_count += 1
            #read csv file as dataframe
            dataframe       = pd.read_csv(dir_name+csv_file_list[self.default_val])
            dataframe["id"] = dataframe.index + 1 #add id as index in dataframe
            # id replace postion as first col in dataframe
            dataframe.set_index(dataframe.columns[-1], inplace=True)
            dataframe.reset_index(inplace=True)        

            #Drop table and load data in mysql table
            if self.schema_flag == 0:
                with engine.begin() as connection:
                    dataframe.to_sql(csv_file_list[self.default_val].split('.')[0].lower(), con=connection,
                                     if_exists='replace', index=False)
            else:
                # Custome Schema build to made in else part
                pass

            # table load time
            tbl_load_time = datetime.datetime.now()            
            print("---------------", csv_file_list[self.default_val].split('.')[0],"---------------",self.default_val)
            msg_dict = {"record_count":dataframe['id'].count(),'process_start_time':process_start_time,
                        'process_end_time':tbl_load_time,'table_name':csv_file_list[self.default_val].split('.')[0]}

            load_response_message = {'version':'1.0', 'status':'Completed', 'message':msg_dict}
        except Exception as e:

            load_response_message = {'version':'1.0', 'status':'Error', 'message':e,
                                     'table_name':csv_file_list[self.default_val].split('.')[0]}
        finally:

            return load_count,load_response_message

"""
While Condition: This will load all data from csv file's from the location 
Auto load all csv files data in above location 
"""    
while len(csv_file_list) != load_count and len(csv_file_list) !=0 and anoop==1:    
    exe_ETL = etl_load_csv(load_count)
    result,load_response_message = exe_ETL.data_insert_mysql()
    if len(csv_file_list) == result:
        print(load_response_message)
        break
    print(load_response_message)
print('Hello-ETL  ------********------  You Completed')


"""
python class to build extract data from json file

"""

"""
Global variable declaration location path
"""
#csv file location
json_dir_name    = CONFIG_OBJ["JSON_FILE_PATH"]['json_file_location']
json_file_name = 'ARMTemplateForFactory.json'
#aaa = None
class extract_data_json:
    def __init__(self):
        pass
    def iter_val_list(self,list_val,key_name):
        try:
            if len(list_val) != 0:
                for z_jsonKey in list_val:
                    if str(type(z_jsonKey)) == "<class 'dict'>":
                        self.iter_val_dict(z_jsonKey)
                    if str(type(z_jsonKey))== "<class 'list'>":
                        self.iter_val_list(z_jsonKey)
                    if str(type(z_jsonKey)) == "<class 'str'>":                    
                        print(z_jsonKey,":::LLLLLL:--->",(z_jsonKey))
        except Exception as e:
            print('LOGGER-ERROR:iter_val_list ',e)
    def iter_val_dict(self,dict_val):
        try:
            for k_jsonKey in dict_val:
                if str(type(dict_val[k_jsonKey])) == "<class 'list'>":
                    #print('DDDDDDDD',dict_val[k_jsonKey])
                    self.iter_val_list(dict_val[k_jsonKey],k_jsonKey)
                if str(type(dict_val[k_jsonKey])) == "<class 'dict'>":
                    self.iter_val_dict(dict_val[k_jsonKey])
                if str(type(dict_val[k_jsonKey])) == "<class 'str'>":                    
                    #if k_jsonKey == 'type':
                        #print(k_jsonKey,":",(dict_val[k_jsonKey]))
                    #pass
                    print(k_jsonKey,":::SSSSSSSSS:--->",(dict_val[k_jsonKey]))
        except Exception as e:
            print('LOGGER-ERROR:iter_val_dict ',e)

    def json_iter_next(self,nxt,data):
        #iter_count = 0
        #dfw = (data["resources"][3])
        #print(data)
        #exit()
        try:
           # while iter_count != nxt:
                #yield data["resources"][iter_count]
            json_resource =  data

            for i_jsonKey in json_resource:
                if i_jsonKey == 'type':
                    if json_resource[i_jsonKey] != 'Microsoft.DataFactory/factories/pipelines':
                        print(i_jsonKey,"KFKFKFKFKF",json_resource[i_jsonKey])
                if str(type(json_resource[i_jsonKey]))== "<class 'dict'>":
                    self.iter_val_dict(json_resource[i_jsonKey])
                    #return aaa
                if str(type(json_resource[i_jsonKey])) == "<class 'str'>":
                    print(i_jsonKey,'qqqqq',json_resource[i_jsonKey])

                #if str(type(json_resource[i_jsonKey])) == "<class 'list'>":
                #    self.iter_val_list(json_resource[i_jsonKey])
                    
                    #print(aaa)

                #yield 1

                #if str(type(thisdict[i]))== ("<class 'dict'>"):

                #iter_count += 1
        except Exception as e:
            print('LOGGER-ERROR:json_iter_next ',e)
        """ 
        try:
            while iter_count != nxt:
                #yield data["resources"][iter_count]
                json_resource =  data["resources"][iter_count]

                for i_jsonKey in json_resource:
                    if i_jsonKey == 'type':
                        if json_resource[i_jsonKey] != 'Microsoft.DataFactory/factories/pipelines':
                            print(json_resource[i_jsonKey])
                    if str(type(json_resource[i_jsonKey]))== "<class 'dict'>":
                        aaa = self.iter_val_dict(json_resource[i_jsonKey])
                        return aaa
                    if str(type(json_resource[i_jsonKey])) == "<class 'list'>":
                        self.iter_val_list(json_resource[i_jsonKey])
                    
                    #print(aaa)

                #yield 1

                #if str(type(thisdict[i]))== ("<class 'dict'>"):

                iter_count += 1
        except Exception as e:
            print('LOGGER-ERROR:json_iter_next ',e)
        """
    def extract_data(self,):
        """
        Extract data from json file data will be order based on pipeline and trigger function  
        Args:
            request: JSON file path or file 
        Return:
            dataframe will retrive form the json file 
        """
        try:
            #laod to json and convert to dataframe to avoid mixing dicts with non-series error           
            data = json.load(open(json_dir_name+json_file_name))
            data_len = len(data["resources"])
            #print(data)
            #data_len=2
            #print(data)
            
            for i in range(1):
                #pass
                print("---------------",i,"------------------")             
                self.json_iter_next(data_len,data["resources"][i])
                #print((data["resources"][i]["properties"]['activities'][0]['type']))
            
            #for value in self.json_iter_next(data_len,data):
            #    pass
                # print each value produced by generator
                #print(value)
            #print(dataq)
            #for i in range(data_len):
            #    pass
                #print((data["resources"][i]["properties"]['activities'][0]['type']))
                #gg.append(data["resources"][i]["properties"]['activities'][0]['type'])
                #print(data["resources"][0]["type"])
                #print(data["resources"][i]["properties"]['activities'][0]['type'])
            #print((gg))

                #print(data["resources"][i]["properties"]['activities'][0]['type'])
            #df = pd.read_json(data["resources"][0]["properties"]['activities'])
            #df = len(data["resources"][0]["properties"]['activities'])
            
            dfw = (data["resources"][1])
            #print(dfw)
            
            #print(type(data["resources"][0]["properties"]['activities'][0]))
                #typeProperties
                #print(data["resources"][i]["properties"]['activities'][0]['typeProperties'])
            """
            for i in range(10):
                print("------------")
                print(data["resources"][i]["properties"]['activities'])
                print("*******")
            #dataframe_json = pd.DataFrame(data)
            """
            """
            try:
                dataframe_json = pd.DataFrame(data["resources"][0])
            except Exception as e:
                if e == "Mixing dicts with non-Series may lead to ambiguous ordering.":
                    print(43234)
                    val_test = self.test(data["resources"][0])
            """

            #dataframe_json = pd.DataFrame(val_test)
            #prin              
            #print(dataframe_json)
        except Exception as e:
            print('logger',e)
        finally:
            pass
    def test(a):
        data_test = json.load(open(a))
        return data_test
    
#anoop=2

if __name__ == '__main__' and anoop == 2:
    print('11')
    json_exe = extract_data_json()
    json_exe.extract_data()



"""

thisdict =	{'name': "[concat(parameters('factoryName'), '/8AMand2PMDailyRefresh')]", 'type': 'Microsoft.DataFactory/factories/pipelines', 'apiVersion': '2018-06-01', 'properties': {'activities': [{'name': 'invoice_stats_global_acct', 'type': 'ExecutePipeline', 'dependsOn': [{'activity': 'Set', 'dependencyConditions': ['Succeeded']}], 'userProperties': [], 'typeProperties': {'pipeline': {'referenceName': 'PL_AAS_REFRESH_SUBMIT', 'type': 'PipelineReference'}, 'waitOnCompletion': True, 'parameters': {'ModelName': 'WCC-SalesPlusModel', 'SendStatusEmailTo': 'osalami@wescodist.com;CYadav@wescodist.com', 'ServerName': 'aasnpsharedwccuat', 'AdvancedModeRequest': 'Y', 'RefreshRequestBody': '{"CommitMode": "transactional","MaxParallelism": 30,"Objects": [\n{"database": "WCC-SalesPlusModel","table": "invoice_stats_global_acct"}],\n"RetryCount": 2,"Type": "Full"}'}}}, {'name': 'sam_daily and sam_daily_grd', 'type': 'ExecutePipeline', 'dependsOn': [{'activity': 'Set', 'dependencyConditions': ['Succeeded']}], 'userProperties': [], 'typeProperties': {'pipeline': {'referenceName': 'PL_AAS_REFRESH_SUBMIT', 'type': 'PipelineReference'}, 'waitOnCompletion': True, 'parameters': {'ModelName': 'WCC-InventoryPlusModel', 'SendStatusEmailTo': 'osalami@wescodist.com;CYadav@wescodist.com', 'ServerName': 'aasnpsharedwccuat', 'AdvancedModeRequest': 'Y', 'RefreshRequestBody': '{"CommitMode": "transactional","MaxParallelism": 30,"Objects": [\n{"database": "WCC-InventoryPlusModel","table": "sam_daily"},\n{"database": "WCC-InventoryPlusModel","table": "sam_daily_grd"}],\n"RetryCount": 2,"Type": "Full"}'}}}, {'name': 'Set', 'type': 'Wait', 'dependsOn': [], 'userProperties': [], 'typeProperties': {'waitTimeInSeconds': 1}}], 'policy': {'elapsedTimeMetric': {}, 'cancelAfter': {}}, 'folder': {'name': 'WCC-CubeRefresh'}, 'annotations': []}, 'dependsOn': ["[concat(variables('factoryId'), '/pipelines/PL_AAS_REFRESH_SUBMIT')]"]}
def list_fuc(b):
    #print((b))
    if len(b) != 0:
        for z in b:
            if str(type(z)) == "<class 'dict'>":
                #print(type(z))
                dict_fuc(z)
            if str(type(z))== "<class 'list'>":
                list_fuc(z)
        
def dict_fuc(a):
    for k in a:
        #print(type(a[k]))
        if str(type(a[k])) == "<class 'list'>":
            list_fuc(a[k])
for i in thisdict:
	#print(i,type(thisdict[i]))
    if str(type(thisdict[i]))== ("<class 'dict'>"):
        dict_fuc(thisdict[i])
#print(thisdict.
#print(thisdict.get('model1234'))



"""

##second

"""
thisdict =	{'name': "[concat(parameters('factoryName'), '/8AMand2PMDailyRefresh')]", 'type': 'Microsoft.DataFactory/factories/pipelines', 'apiVersion': '2018-06-01', 'properties': {'activities': [{'name': 'invoice_stats_global_acct', 'type': 'ExecutePipeline', 'dependsOn': [{'activity': 'Set', 'dependencyConditions': ['Succeeded']}], 'userProperties': [], 'typeProperties': {'pipeline': {'referenceName': 'PL_AAS_REFRESH_SUBMIT', 'type': 'PipelineReference'}, 'waitOnCompletion': True, 'parameters': {'ModelName': 'WCC-SalesPlusModel', 'SendStatusEmailTo': 'osalami@wescodist.com;CYadav@wescodist.com', 'ServerName': 'aasnpsharedwccuat', 'AdvancedModeRequest': 'Y', 'RefreshRequestBody': '{"CommitMode": "transactional","MaxParallelism": 30,"Objects": [\n{"database": "WCC-SalesPlusModel","table": "invoice_stats_global_acct"}],\n"RetryCount": 2,"Type": "Full"}'}}}, {'name': 'sam_daily and sam_daily_grd', 'type': 'ExecutePipeline', 'dependsOn': [{'activity': 'Set', 'dependencyConditions': ['Succeeded']}], 'userProperties': [], 'typeProperties': {'pipeline': {'referenceName': 'PL_AAS_REFRESH_SUBMIT', 'type': 'PipelineReference'}, 'waitOnCompletion': True, 'parameters': {'ModelName': 'WCC-InventoryPlusModel', 'SendStatusEmailTo': 'osalami@wescodist.com;CYadav@wescodist.com', 'ServerName': 'aasnpsharedwccuat', 'AdvancedModeRequest': 'Y', 'RefreshRequestBody': '{"CommitMode": "transactional","MaxParallelism": 30,"Objects": [\n{"database": "WCC-InventoryPlusModel","table": "sam_daily"},\n{"database": "WCC-InventoryPlusModel","table": "sam_daily_grd"}],\n"RetryCount": 2,"Type": "Full"}'}}}, {'name': 'Set', 'type': 'Wait', 'dependsOn': [], 'userProperties': [], 'typeProperties': {'waitTimeInSeconds': 1}}], 'policy': {'elapsedTimeMetric': {}, 'cancelAfter': {}}, 'folder': {'name': 'WCC-CubeRefresh'}, 'annotations': []}, 'dependsOn': ["[concat(variables('factoryId'), '/pipelines/PL_AAS_REFRESH_SUBMIT')]"]}
def list_fuc(b):
    #print((b))
    if len(b) != 0:
        for z in b:
            #print(type(z))
            if str(type(z)) == "<class 'dict'>":
                #print(type(z))
                dict_fuc(z)
            if str(type(z))== "<class 'list'>":
                list_fuc(z)
        
def dict_fuc(a):
    for k in a:
        #print(type(a[k]))
        #print(type(a[k]))
        if str(type(a[k])) == "<class 'list'>":
            #pass
            #print(k)
            list_fuc(a[k])
        if str(type(a[k])) == "<class 'dict'>":
            dict_fuc(a[k])
        if str(type(a[k])) == "<class 'str'>":
            print(a[k])
        #    print(a)
for i in thisdict:
    #print(i)
    if i == 'type':
        if thisdict[i] != 'Microsoft.DataFactory/factories/pipelines':
            print(thisdict[i])
	   #print()
    if str(type(thisdict[i]))== ("<class 'dict'>"):
        dict_fuc(thisdict[i])
    if str(type(thisdict[i])) == "<class 'list'>":
        list_fuc(thisdict[i])
    #print(type(thisdict[i]))
    #if str(type(thisdict[i]))== ("<class 'dict'>"):
        #dict_fuc(thisdict[i])
#print(thisdict.
#print(thisdict.get('model1234'))

"""

#third

"""
thisdict =	{'name': "[concat(parameters('factoryName'), '/8AMand2PMDailyRefresh')]", 'type': 'Microsoft.DataFactory/factories/pipelines', 'apiVersion': '2018-06-01', 'properties': {'activities': [{'name': 'invoice_stats_global_acct', 'type': 'ExecutePipeline', 'dependsOn': [{'activity': 'Set', 'dependencyConditions': ['Succeeded']}], 'userProperties': [], 'typeProperties': {'pipeline': {'referenceName': 'PL_AAS_REFRESH_SUBMIT', 'type': 'PipelineReference'}, 'waitOnCompletion': True, 'parameters': {'ModelName': 'WCC-SalesPlusModel', 'SendStatusEmailTo': 'osalami@wescodist.com;CYadav@wescodist.com', 'ServerName': 'aasnpsharedwccuat', 'AdvancedModeRequest': 'Y', 'RefreshRequestBody': '{"CommitMode": "transactional","MaxParallelism": 30,"Objects": [\n{"database": "WCC-SalesPlusModel","table": "invoice_stats_global_acct"}],\n"RetryCount": 2,"Type": "Full"}'}}}, {'name': 'sam_daily and sam_daily_grd', 'type': 'ExecutePipeline', 'dependsOn': [{'activity': 'Set', 'dependencyConditions': ['Succeeded']}], 'userProperties': [], 'typeProperties': {'pipeline': {'referenceName': 'PL_AAS_REFRESH_SUBMIT', 'type': 'PipelineReference'}, 'waitOnCompletion': True, 'parameters': {'ModelName': 'WCC-InventoryPlusModel', 'SendStatusEmailTo': 'osalami@wescodist.com;CYadav@wescodist.com', 'ServerName': 'aasnpsharedwccuat', 'AdvancedModeRequest': 'Y', 'RefreshRequestBody': '{"CommitMode": "transactional","MaxParallelism": 30,"Objects": [\n{"database": "WCC-InventoryPlusModel","table": "sam_daily"},\n{"database": "WCC-InventoryPlusModel","table": "sam_daily_grd"}],\n"RetryCount": 2,"Type": "Full"}'}}}, {'name': 'Set', 'type': 'Wait', 'dependsOn': [], 'userProperties': [], 'typeProperties': {'waitTimeInSeconds': 1}}], 'policy': {'elapsedTimeMetric': {}, 'cancelAfter': {}}, 'folder': {'name': 'WCC-CubeRefresh'}, 'annotations': []}, 'dependsOn': ["[concat(variables('factoryId'), '/pipelines/PL_AAS_REFRESH_SUBMIT')]"]}
def list_fuc(b):
    #print((b))
    if len(b) != 0:
        for z in b:
            #print(type(z))
            if str(type(z)) == "<class 'dict'>":
                #print(type(z))
                dict_fuc(z)
            if str(type(z))== "<class 'list'>":
                list_fuc(z)
        
def dict_fuc(a):
    for k in a:
        #print(type(a[k]))
        #print(type(a[k]))
        if str(type(a[k])) == "<class 'list'>":
            #pass
            #print(k)
            list_fuc(a[k])
        if str(type(a[k])) == "<class 'dict'>":
            dict_fuc(a[k])
        if str(type(a[k])) == "<class 'str'>":
            #pass
            print(k,":",(a[k]))
        #    print(a)
for i in thisdict:
    #print(i)
    if i == 'type':
        if thisdict[i] != 'Microsoft.DataFactory/factories/pipelines':
            print(thisdict[i])
	   #print()
    if str(type(thisdict[i]))== ("<class 'dict'>"):
        dict_fuc(thisdict[i])
    if str(type(thisdict[i])) == "<class 'list'>":
        list_fuc(thisdict[i])
    #print(type(thisdict[i]))
    #if str(type(thisdict[i]))== ("<class 'dict'>"):
        #dict_fuc(thisdict[i])
#print(thisdict.
#print(thisdict.get('model1234'))

"""