"""
Author/File Name/Developer   : Xoriant team / wesco_import_script.py/Anoop
Project Description: ETL Script to import the CSV data in mySQL db using python
Deployement method :
Git repo           :
"""
from ast import Pass
from configparser import ConfigParser
from ssl import OPENSSL_VERSION_INFO
import pandas as pd
import mysql.connector
from sqlalchemy import create_engine
import datetime
import os
import json
import numpy as np



#setup config file 
CONFIG_OBJ = ConfigParser()
CONFIG_OBJ.read("./config.ini")

"""
Global config -  varibale to automate load the csv in mysql db
"""
#csv file location
dir_name        = CONFIG_OBJ["FILE_PATH"]['file_location']
csv_file_list   = [file for file in os.listdir(dir_name)] # List of csv file name in above location
load_count      = 0
user_input = input("Enter the input choose '1':(For cvs import data in mysql db) & choose '2':(Export JSON to csv files)  : ")
if (user_input) != '1' and (user_input) != '2':
    print("Enter valid option 1 or 2")
    exit()
#input_variable           = int(user_input)
input_variable           = 3
#exit('234567654')
#db connecttion:
connection_string   = CONFIG_OBJ["DB_CONN_LOCAL"]['db_env']
engine              = create_engine(connection_string)
engine.connect()

# Load time cal
process_start_time = datetime.datetime.now()
# custome schema build table name
custome_table_list = CONFIG_OBJ["CUSTOM_SCHEMA"]['table_name']
# auto increment false
auto_increment_false = CONFIG_OBJ["TABLE_AUTO_INCREMENT_FALSE"]['table_name_auto_false']

class etl_load_csv:
    
    def __init__(self,default=0):
        self.default_val = default
        # condition to check for custome_schema 
        if(csv_file_list[default].split('.')[0]) in custome_table_list:
            self.schema_flag = 1
        else:
            self.schema_flag = 0    
    
    def data_insert_mysql(self,):
        """
        Fetch CSV-file and covert data as dataframe and load in mysql db
        Args:
            request: CSV file as a agrs fetch from the location path
        Return:
            Logg message of data table values (toal record value in db and csv file record count)
        """
        try:
            # Count csv file in location and load data in mysql one by one index in list
            global load_count
            load_count += 1

            #read csv file as dataframe
            dataframe       = pd.read_csv(dir_name+csv_file_list[self.default_val])

            if csv_file_list[self.default_val].split('.')[0] not in auto_increment_false:
                dataframe["id"] = dataframe.index + 1 #add id as index in dataframe
                # id replace postion as first col in dataframe
                dataframe.set_index(dataframe.columns[-1], inplace=True)
                dataframe.reset_index(inplace=True)
            #Drop table and load data in mysql table
            if self.schema_flag == 0:
                with engine.begin() as connection:
                    dataframe.to_sql(csv_file_list[self.default_val].split('.')[0].lower(), con=connection,
                                     if_exists='replace', index=False)
            else:
                # Custome Schema build to made in else part
                pass

            # table load time
            tbl_load_time = datetime.datetime.now()            
            print("---------------", csv_file_list[self.default_val].split('.')[0],"---------------",self.default_val)
            msg_dict = {"record_count":dataframe['id'].count(),'process_start_time':process_start_time.strftime("%m/%d/%Y, %H:%M:%S"),
                        'process_end_time':tbl_load_time.strftime("%m/%d/%Y, %H:%M:%S"),'table_name':csv_file_list[self.default_val].split('.')[0]}

            load_response_message = {'version':'1.0', 'status':'Completed', 'message':msg_dict}
        except Exception as e:

            load_response_message = {'version':'1.0', 'status':'Error', 'message':e,
                                     'table_name':csv_file_list[self.default_val].split('.')[0]}
        finally:

            return load_count,load_response_message

"""
While Condition: This will load all data from csv file's from the location 
Auto load all csv files data in above location 
"""    
while len(csv_file_list) != load_count and len(csv_file_list) !=0 and input_variable==1:    
    exe_ETL = etl_load_csv(load_count)
    result,load_response_message = exe_ETL.data_insert_mysql()
    if len(csv_file_list) == result:
        print(load_response_message)
        break
    print(load_response_message)
print('Hello-ETL  ------********------  You Completed')

"""
python class to build extract data from json file

"""

"""
Global variable declaration location path
"""
#csv file location
json_dir_name    = CONFIG_OBJ["JSON_FILE_PATH"]['json_file_location']
json_file_name = '8AMand2PMDailyRefresh.json'

#pipeline global static @para

dir_name_pipeline_json       = CONFIG_OBJ["JSON_FILE_PATH"]['pipeline_json_file_location']
pipeline_json_file_list   = [file for file in os.listdir(dir_name_pipeline_json)]
json_count_pipeline = 0

pipeline_name_list=[]
activities_count_list = []
folder_name_list=[]
parent_pip_name_list=[]

#trigger global static @para

dir_name_trigger_json       = CONFIG_OBJ["JSON_FILE_PATH"]['trigger_json_file_location']
trigger_json_file_list   = [file for file in os.listdir(dir_name_trigger_json)]
json_count_trigger = 0

trigger_id_list=[]
trigger_name_list = []
trtigger_type_list=[]
trigger_details_list = []

class extract_data_json:
    def __init__(self,default=0):
        self.default_val = default
    def iter_val_list(self,list_val):
        try:
            if len(list_val) != 0:
                for z_jsonKey in list_val:
                    if str(type(z_jsonKey)) == "<class 'dict'>":
                        self.iter_val_dict(z_jsonKey)
                    if str(type(z_jsonKey))== "<class 'list'>":
                        self.iter_val_list(z_jsonKey)
                    if str(type(z_jsonKey)) == "<class 'str'>":                    
                        print(z_jsonKey,":::LLLLLL:--->",(z_jsonKey))
        except Exception as e:
            print('LOGGER-ERROR:iter_val_list ',e)
    def iter_val_dict(self,dict_val):
        try:
            for k_jsonKey in dict_val:
                if str(type(dict_val[k_jsonKey])) == "<class 'list'>":
                    #print('DDDDDDDD',dict_val[k_jsonKey])
                    self.iter_val_list(dict_val[k_jsonKey])
                if str(type(dict_val[k_jsonKey])) == "<class 'dict'>":
                    self.iter_val_dict(dict_val[k_jsonKey])
                if str(type(dict_val[k_jsonKey])) == "<class 'str'>":                    
                    #if k_jsonKey == 'type':
                        #print(k_jsonKey,":",(dict_val[k_jsonKey]))
                    #pass
                    print(k_jsonKey,":::SSSSSSSSS:--->",(dict_val[k_jsonKey]))
        except Exception as e:
            print('LOGGER-ERROR:iter_val_dict ',e)

    def json_iter_next(self,nxt,data):

        try:
            json_resource =  data
            for i_jsonKey in json_resource:
                if i_jsonKey == 'type':
                    if json_resource[i_jsonKey] != 'Microsoft.DataFactory/factories/pipelines':
                        print(json_resource[i_jsonKey])
                if str(type(json_resource[i_jsonKey]))== "<class 'dict'>":
                    self.iter_val_dict(json_resource[i_jsonKey])
                    #return aaa
                if str(type(json_resource[i_jsonKey])) == "<class 'str'>":
                    print('qqqqq',json_resource[i_jsonKey])
        except Exception as e:
            print('LOGGER-ERROR:json_iter_next ',e)
 
    def extract_data(self,):
        """
        Extract data from json file data will be order based on pipeline and trigger function  
        Args:
            request: JSON file path or file 
        Return:
            dataframe will retrive form the json file 
        """
        try:
            #laod to json and convert to dataframe to avoid mixing dicts with non-series error           
            data = json.load(open(json_dir_name+json_file_name))
            data_len = len(data["resources"])
            
            
            for i in range(data_len):
                #pass
                print("---------------",i,"------------------")             
                #self.json_iter_next(data_len,data["resources"][i])
                #print((data["resources"][i]["properties"]['activities'][0]['type']))
            
        except Exception as e:
            print('logger',e)
        finally:
            pass
    

    def pipline_exe(self,):
        """
        Extract data from json file data will be order based on pipeline and trigger function  
        Args:
            request: JSON file path or file 
        Return:
            dataframe will retrive form the json file 
        """
        #print()
        
        try:            
            df = pd.read_json(dir_name_pipeline_json+pipeline_json_file_list[self.default_val])            
            pip_active_count=(len(df['properties']['activities']))
            pip_folder=((df['properties']['folder']['name'].split("/")[0]))
            pip_name=(pipeline_json_file_list[self.default_val].split(".")[0])
            pipeline_name_list.append(pip_name)
            activities_count_list.append(pip_active_count)
            folder_name_list.append(pip_folder)
            ll=[]

            active_check = (df['properties']['activities'])
            flag=0
            for i in range(pip_active_count):
                check_child_pip = active_check[i].get("typeProperties",{}).get('pipeline')
                if check_child_pip != None:
                    flag = 1                        
                    val_pip_name =  check_child_pip.get('referenceName')
                    ll.append(val_pip_name)
                    set_val= set(ll)
                    child_pipline_name_loop = set_val.copy()
            if flag ==1:
                parent_pip_name_list.append(child_pipline_name_loop)
            else:
                parent_pip_name_list.append(None)
            ll.clear()
            
            #response_val={'Pipeline_Name':pipeline_name_list,'Activities_Count':activities_count_list,'Folder_Name':folder_name_list,
            #              'Trigger_status':0,'Trigger_id':0}
            
            response_val={'Pipeline_Name':pipeline_name_list,'Activities_Count':activities_count_list,'Folder_Name':folder_name_list,
                          'Child_pipiline_names':parent_pip_name_list,'parent_pipiline_name':None}
            
            global json_count_pipeline
            json_count_pipeline += 1

            if len(pipeline_json_file_list) == json_count_pipeline:
                #print(response_val)
                return json_count_pipeline,response_val
            else:
                #pass
                return json_count_pipeline,response_val
                #print('response_val')
        except Exception as e:            
            print(e)

#intermediate table
pipline_id_val =[] 
trigger_id_val = []
#parameter:
para_name_list=[]
para_val_list=[]
pipline_id_para=[]
trigger_id_pra=[]

class trigger_export():
    def __init__(self,default=0):
        self.trigger_val = default
        self.inter_response_df = {}
        self.para_response_df={}
        #self.json_count_pipeline = 
    def trigger_exe(self,):

        """
        Extract data from json file data will be order based on pipeline and trigger function  
        Args:
            request: JSON file path or file 
        Return:
            dataframe will retrive form the json file 
        """
        #print()
        
        try:
            #pp = super().pipline_exe()
            #print(pp)
            trigger_df = pd.read_json(dir_name_trigger_json+trigger_json_file_list[self.trigger_val])
            #print(trigger_df['properties']['type'])
            #print(trigger_df['name']['annotations'])
            index_val = self.trigger_val +1
            v =trigger_json_file_list[self.trigger_val]
            #print(index_val,"------",self.trigger_val)
            csv_file_path = CONFIG_OBJ["CSV_DF_PATH"]['path']
            csv_file_name = CONFIG_OBJ["CSV_DF_PATH"]['pipeline_file_name']

            """
            #if len((trigger_df['properties']['pipelines'])) != 0:
            if len((trigger_df['properties']['pipelines'])) > 1:

                for i in (((trigger_df['properties']['pipelines']))):
                    #x = car.get("model")
                    par_val = i.get('parameters')
                    if par_val != None:
                        for j in par_val:
                            print('para_name',j)
                            print('para_val',par_val[j])

                    print('---',par_val)
                    #print(i['pipelineReference']['referenceName']['anoop'])
                #print(((trigger_df['properties']['pipelines'])))
                exit()
            """
            #Inter mediate table pipline and trigger and parameter
            pipeline_key_check = ((trigger_df['properties']))
            pipline_stat = pipeline_key_check.get("pipelines")
            if pipline_stat != None:
                if len((trigger_df['properties']['pipelines'])) != 0:
                    #print(1)
                    #csv_df       = pd.read_csv(csv_file_path+csv_file_name,index_col=0)
                    csv_df       = pd.read_csv(csv_file_path+csv_file_name)
                    #print(df.to_csv(index=False))
                    #filter1 = csv_df["Pipeline_Name"]==trigger_df['properties']['pipelines']
                    
                    for i in (((trigger_df['properties']['pipelines']))):
                        #filter1 = csv_df["Pipeline_Name"]== (i['pipelineReference']['referenceName'])
                        #csv_df.set_index(csv_df.columns[-1], inplace=False)
                        #csv_df.reset_index(inplace=False)
                        filter1 = csv_df.loc[csv_df['Pipeline_Name'] == (i['pipelineReference']['referenceName'])].values.tolist()
                        pip_id = ((filter1[0][0]))# id value                        
                        pipline_id_val.append(pip_id)
                        trigger_id_val.append(index_val)

                        # parameter value stroe:
                        par_val = i.get('parameters')
                        if par_val != None:
                            for j in par_val:
                                para_name_list.append(j)
                                para_val_list.append(par_val[j])
                                pipline_id_para.append(pip_id)
                                trigger_id_pra.append(index_val)
                            self.para_response_df = {"pipline_id":pipline_id_para,"trigger_id":trigger_id_pra,'para_name':para_name_list,
                                                      "para_val":para_val_list}
                    self.inter_response_df = {"pipline_id":pipline_id_val,"trigger_id":trigger_id_val}            
            
            if trigger_df['properties']['type'] == 'ScheduleTrigger':
                #pass
                
                #""
                trigger_type_val = (trigger_df['properties']['type'])
                trigger_name_val=(trigger_df['name']['annotations'])
                trigger_details_val=(trigger_df['properties']['typeProperties']['recurrence'])
                trigger_id_list.append(index_val)
                trigger_name_list.append(trigger_name_val)
                trtigger_type_list.append(trigger_type_val)
                trigger_details_list.append(trigger_details_val)
                
                #response_val_trigger = {'id':trigger_id_list,'Trigger_name':trigger_name_list,'Trigger_type':trtigger_type_list,
                #                        'Trigger_details':trigger_details_list}
                
                
                
                #print(trigger_df['properties']['type'])
                #print(trigger_df['name']['annotations'])
                #print(trigger_df['properties']['typeProperties']['recurrence'])
            else:
                #pass
                
                if trigger_df['properties']['type'] == 'BlobEventsTrigger':
                    trigger_type_val = (trigger_df['properties']['type'])
                    trigger_name_val=(trigger_df['name']['annotations'])
                    #trigger_details_val=(trigger_df['properties']['typeProperties']['recurrence'])
                    path_dir_name = (trigger_df['properties']['typeProperties']['blobPathBeginsWith'].split('/')[2:])

                    path_dir_name_end_check = (trigger_df['properties']['typeProperties'])
                    end_path_val = path_dir_name_end_check.get("blobPathEndsWith") # check null value

                    path_dir_name_join = ("/".join(path_dir_name))
                    tri_detils = {"BlobEvents_StorageAccName":(trigger_df['properties']['typeProperties']['scope'].split('/')[-1]),
                        "BlobEvents_StorageContainerName":(trigger_df['properties']['typeProperties']['blobPathBeginsWith'].split('/')[1]),
                        "BlobEvents_BlobPathBegin":path_dir_name_join,"BlobEvents_BlobPathEnd":end_path_val}
                    
                    trigger_id_list.append(index_val)
                    trigger_name_list.append(trigger_name_val)
                    trtigger_type_list.append(trigger_type_val)
                    trigger_details_list.append(tri_detils)
                else:
                    trigger_type_val = (trigger_df['properties']['type'])
                    trigger_name_val=(trigger_df['name']['annotations'])
                    tri_detils = None

                    trigger_id_list.append(index_val)
                    trigger_name_list.append(trigger_name_val)
                    trtigger_type_list.append(trigger_type_val)
                    trigger_details_list.append(tri_detils)
                
                #print('pasaas')
                #exit()

                """
                #print(trigger_df)
                print(trigger_df['name']['annotations'])
                print(trigger_df['properties']['type'])
                print(trigger_df['properties']['typeProperties']['scope'].split('/')[-1])
                
                print(trigger_df['properties']['typeProperties']['blobPathBeginsWith'].split('/')[1])
                print(trigger_df['properties']['typeProperties']['blobPathBeginsWith'].split('/')[2:])
                qq = (trigger_df['properties']['typeProperties']['blobPathBeginsWith'].split('/')[2:])
                print(trigger_df['properties']['typeProperties']['blobPathEndsWith'])
                print("/".join(qq))
                 
                exit()
                """

            response_val_trigger = {'id':trigger_id_list,'Trigger_name':trigger_name_list,
                                    'Trigger_type':trtigger_type_list,'Trigger_details':trigger_details_list}
            
            #print(response_val_trigger)
                
            #pip_active_count=(len(df['properties']['activities']))
            #pip_folder=((df['properties']['folder']['name'].split("/")[0]))
            #pip_name=(pipeline_json_file_list[self.default_val].split(".")[0])
            #pipeline_name_list.append(pip_name)
            #activities_count_list.append(pip_active_count)
            #folder_name_list.append(pip_folder)
            
            #response_val={'Pipeline_Name':pipeline_name_list,'Activities_Count':activities_count_list,'Folder_Name':folder_name_list,
                          #'Trigger_status':0,'Trigger_id':0}
            #print("rtyuioiuytr",self.trigger_val)
            
            global json_count_trigger
            json_count_trigger += 1
            #print(response_val_trigger)
            #exit()
            
            #response_val = {'A':1}
            #print(json_count_trigger)
            return json_count_trigger,response_val_trigger,self.inter_response_df,self.para_response_df
            """
            if len(trigger_json_file_list) == json_count_trigger:
                print('response_val')
                return json_count_trigger,response_val
            else:
                #pass
                return json_count_trigger,response_val
                print('response_valq')
            """
        except Exception as e:
            print(v,e)

# LINK SERVICE ############################

dir_name_link_service_json       = CONFIG_OBJ["JSON_FILE_PATH"]['link_service_file_location']
link_json_file_list   = [file for file in os.listdir(dir_name_link_service_json)]
json_count_link_service = 0

id_link_service_list = []
link_service_name_list = []
link_service_type_list = []
azure_stat_list = []
integration_runtime_id_list = []

#parameter value
#para_val_list = []
link_id_list =[]
conn_para_stat_list =[]
file_name_ls = []
para_val = []

integrationRuntime_dict = {"AzureIntRunManaged":1,"ir-email-ddp-eastus-dev":2,"WescoOnPremIntRunTimeDev01":3}

class link_service():
    def __init__(self,default=0):
        self.link_service_val = default
    def link_service_export(self,):
        try:
            #print((self.link_service_val))
            link_service_df = pd.read_json(dir_name_link_service_json+link_json_file_list[self.link_service_val])
            #print(trigger_df['properties']['type'])
            
            #print(link_service_df['name'])
            index_val = self.link_service_val +1
            link_service_name = (link_service_df['name']['annotations'])
            link_service_type = (link_service_df['properties']['type'])
            if link_service_df['properties']['type'] == "AzureKeyVault":
                azure_stat = 1
            else:
                azure_stat = 0
            link_prpoerties = (link_service_df['properties'])
            par_val = link_prpoerties.get('connectVia')
            if par_val != None:
                integration_runtime_id_stat = (integrationRuntime_dict[par_val['referenceName']])
                #print(par_val['referenceName'])
            else:
                integration_runtime_id_stat = 0

            id_link_service_list.append(index_val)
            link_service_name_list.append(link_service_name)
            link_service_type_list.append(link_service_type)
            azure_stat_list.append(azure_stat)
            integration_runtime_id_list.append(integration_runtime_id_stat)

            file_name_json =link_json_file_list[self.link_service_val]
           
            response_link_service_dict = {'id':id_link_service_list,'link_service_name':link_service_name_list,'link_service_type':link_service_type_list,
                                          'azure_state':azure_stat_list,'integration_runtime_id':integration_runtime_id_list}
            
            #link service parameter dict
            properties_typepro_check= (link_service_df['properties']['typeProperties']) #parameters
            properties_check = (link_service_df['properties'])
            par_val = properties_check.get('parameters')
            #print(11)
            conn_par_stat= None
            if par_val != None:
                conn_par_stat=1
                #para_val_list.clear()
                para_val_list = [i for i in par_val.keys()]
                #for i in par_val.keys():
                #    para_val_list.append(i)
                para_name_output = (para_val_list)
            else:
                par_val_co = properties_typepro_check.get('connectionString')
                if par_val_co != None:
                    conn_par_stat=2
                    para_name_output = par_val_co
                else:
                    conn_par_stat=0
                    para_name_output = None
            para_val.append(para_name_output)
            file_name_ls.append(file_name_json)
            conn_para_stat_list.append(conn_par_stat)
            #print(para_name_output)
            response_link_service_para_dict = {"servie_link_id":id_link_service_list,"parameter_name":para_val,"file_name":file_name_ls,
                                               "conn_para_stat":conn_para_stat_list}
            #print(response_link_service_para_dict)
            """
            cc_g = ccc.get('connectionString')
            if cc_g != None and r==0:
                par_val = cc_g
            else:
                if r !=1:
                    par_val ='anoop'
            print(par_val)
            """
            """
            if cc == None:
                ccc = (link_service_df['properties'])
                par_val = ccc
            else:
                par_val = cc.get('connectionString')
            print(par_val)
            #exit()
            """

            global json_count_link_service
            json_count_link_service += 1
            #print((json_count_link_service))
            return json_count_link_service,response_link_service_dict,response_link_service_para_dict
        except Exception as e:
            print(file_name_json,"LOgger link", e)

dir_name_datasource_json       = CONFIG_OBJ["JSON_FILE_PATH"]['datasource_file_location']
datasource_json_file_list   = [file for file in os.listdir(dir_name_datasource_json)]
json_count_datasource = 0

csv_file_path_service = CONFIG_OBJ["CSV_DF_PATH"]['path']
csv_file_name_service = CONFIG_OBJ["CSV_DF_PATH"]['service_link_file_name']

csv_service_df       = pd.read_csv(csv_file_path_service+csv_file_name_service)

source_name_list = []
source_link_name_list = []
link_id_list=[]
link_service_parameter_list =[]


class datasource:
    def __init__(self,default=0):
        self.datasource_val = default
    def datasource_export(self):
        try:
            #print(self.datasource_val)
            #exit()
            v=(self.datasource_val,"-------",dir_name_datasource_json+datasource_json_file_list[self.datasource_val])
            #print(self.datasource_val)
            datasource_df = pd.read_json(dir_name_datasource_json+datasource_json_file_list[self.datasource_val])
            datasource_name = (datasource_df['name']['annotations'])
            
            link_properties = ((datasource_df['properties'])) #No parameters
            link_service_name = link_properties.get("linkedServiceName",{}).get('referenceName')
            """
            if link_properties != None:
                link_service_name = 'anoop'
                #link_service_name = link_properties.get("linkedServiceName",{}).get('referenceName')
                
                link_service_dict = link_properties.get("linkedServiceName")
                if link_service_dict != None:
                    link_service_name = link_properties.get("referenceName") if link_properties.get("referenceName") != None else None
                else:
                    link_service_name = None
            else:
                link_service_name = None
            """
            
            link_service_parameter = link_properties.get("parameters")
            link_service_parameter_val = [ i for i in (datasource_df['properties']['parameters'])] if link_service_parameter != None else None
            
            if link_service_name !=  None:            
                filter2 = csv_service_df.loc[csv_service_df['link_service_name'] == (link_service_name)].values.tolist()           
                link_service_id = ((filter2[0][0]))# id value
            else:
                link_service_id = None
            
            #print('link_service_id',link_service_id)

            #print('link_service_parameter_val',link_service_parameter_val)
            #print('link_service_name',link_service_name)
            #print('datasource_name',link_service_id)
            source_name_list.append(datasource_name)
            source_link_name_list.append(link_service_name)
            link_id_list.append(link_service_id)
            link_service_parameter_list.append(link_service_parameter_val)
            response_datasource_result = {'source_name':source_name_list,'link_source_name':source_link_name_list,'link_id':link_id_list,
                                          'paramter_val':link_service_parameter_list}
            
            #exit()
            #global json_count_datasource
            #json_count_datasource += 1
            #return json_count_datasource,response_datasource_result
            
            
        except Exception as e:
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print(v,"LOGGER - DS", e)
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print("--------------------")
        
        finally:

            global json_count_datasource
            json_count_datasource += 1
            return json_count_datasource,response_datasource_result
        
dir_name_pipeline_json       = CONFIG_OBJ["JSON_FILE_PATH"]['pipeline_json_file_location']
pipeline_json_file_list   = [file for file in os.listdir(dir_name_pipeline_json)]
json_count_pipeline = 0
final_res_anoop = None

# Global file path JSON
global_file_location = CONFIG_OBJ["GLOBAL_FILE_PATH"]['global_file_name']
global_df = pd.read_json(global_file_location)

key_data_loop = []
val_data_loop=[]

key_data = []
val_data=[]

key_data1=[]
val_data1=[]

key_data_s = []
val_data_s=[]
q=[]
qa=[]
dk={}
dv={}

respnse_child_loop_pip=[]
respnse_child_loop_para=[]
respnse_child_loop_ds=[]
respnse_child_loop_val=[]

respnse_child_loop_nested_pip=[]
respnse_child_loop_nested_para=[]
respnse_child_loop_nested_val=[]
respnse_child_loop_nested_ds=[]

respnse_child_loop_parent_pip=[]
respnse_child_loop_parent_para=[]
respnse_child_loop_parent_ds=[]
respnse_child_loop_parent_val=[]

class pipline_dataset:
    def __init__(self,default=0,sandeep=None):
        self.pipline_ds_val = default
        
        self.loop_key_responce = []
        self.value_after_responce=[]
        self.secondary_loop_list_res = []
        self.secondary_loop_flag = 0

        self.nested_flag = 0
        self.nested_loop_key_responce = []
        self.nested_value_after_responce=[]
        self.nested_secondary_loop_list_res = []

        self.parent_loop_flag = 0
        self.parent_loop_key_responce = []
        self.parent_value_after_responce=[]
        self.check_all_stat = 0
        if sandeep == None:
            self.sandeep = []
    def extract_pipeline_dataset(self,):
        try:
            v=(self.pipline_ds_val,"-------",dir_name_pipeline_json+pipeline_json_file_list[self.pipline_ds_val])
            #print(self.datasource_val)
            pipeline_dataset_df = pd.read_json(dir_name_pipeline_json+pipeline_json_file_list[self.pipline_ds_val])
            pip_name = (pipeline_dataset_df['name']['annotations'])
            
            #8AMand2PMDailyRefresh
            unit_test_stat=1
            if (pipeline_json_file_list[self.pipline_ds_val]) != "PL_Shell_Driver_Demand_BY_ES.json" and unit_test_stat == 1:
                pipeline_dataset_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'text_file_dataset.txt',index=False)
                with open(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'text_file_dataset.txt','r') as file_check_ds:
                    file_check_dataset=0
                    for index, line in enumerate(file_check_ds):
                        if "'dataset':" in line:
                            file_check_dataset=1
                            break
                        else:
                            file_check_dataset=2                           
                    #print(file_check_dataset)

            #@AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
            
            #Exec_fah_file_config_db_tbl_ap_notebook
            #if (pipeline_json_file_list[self.pipline_ds_val]) == "fah_file_config_tbl_ar_balances.json":
            
            #if (pipeline_json_file_list[self.pipline_ds_val]) == "Exec_fah_file_config_db_tbl_ap_notebook.json":
            #if (pipeline_json_file_list[self.pipline_ds_val]) == "Exec_fah_file_config_db_tbl_ap_notebook.json":
            #if (pipeline_json_file_list[self.pipline_ds_val]) == "PL_Shell_Driver_Demand_BY_ES.json":
            #parameters
            #PL_Shell_Driver_Demand_BY_ES
            if unit_test_stat == 1 and (pipeline_json_file_list[self.pipline_ds_val]) != "PL_Shell_Driver_Demand_BY_ES.json" and file_check_dataset==1:
            #if (anoop) == 1:
                #print("************NAME*******",pip_name)
                x =  (((pipeline_dataset_df['properties']['activities'])))
                #for i in (pipeline_dataset_df['properties']['activities']) :
                for i in range (len((pipeline_dataset_df['properties']['activities']))):
                    link_service_dataset = x[i].get("typeProperties",{}).get('dataset')
                    #print(link_service_dataset)
                    #parameters_check_parent = link_service_dataset.get('parameters')   #['parameters']
                    
                    if i == 0 and link_service_dataset != None:
                        #print(11111)
                        self.parent_loop_flag=1
                        #respnse={}
                        link_name_parent = (link_service_dataset['referenceName']) # reference name
                        #print(link_name,"***")
                        #print("--------------------")
                        #print("--------------------")
                        for k,z in (link_service_dataset['parameters']).items():
                            if str(type(z)) == "<class 'dict'>":
                                #pass
                                #print(k,"---------",z['value'])
                                split_val = z["value"].split(".")
                                if split_val[0] == '@pipeline()' and len(split_val) > 1:
                                    if "globalParameters" in split_val:
                                        global_val = split_val[-1]
                                        # global
                                        out_value = (global_df[global_val]['value'])
                                        #global_df.get("typeProperties",{}).get('dataset')
                                    else:
                                        out_value = split_val[-2] + split_val[-1]
                                else:
                                    out_value = split_val[0]
                                key_data.append(k)
                                val_data.append(out_value)
                                #if z["value"]
                                #print(out_value,"-------K-------------")
                            else:
                                #pass
                                #print(k,"---------",z)
                                #print("-------Z-------------")
                                key_data.append(k)
                                val_data.append(z)

                            

                            key_value_pp = key_data.copy()
                            value_after_pp = val_data.copy()
                            

                            key_data1.append(key_value_pp)
                            val_data1.append(value_after_pp)

                            self.parent_loop_key_responce.append(key_value_pp)
                            self.parent_value_after_responce.append(value_after_pp)

                            #self.parent_loop_key_responce.append(key_data1)
                            #self.parent_value_after_responce.append(val_data1)
                        key_data.clear()
                        val_data.clear()
                            

                        """
                            self.nested_secondary_loop_list_res.append(re_name)
                                key_value_after_nestedloop = key_data_loop.copy()
                                value_after_nested_loop = val_data_loop.copy()
                                self.nested_loop_key_responce.append(key_value_after_nestedloop)
                                self.nested_value_after_responce.append(value_after_nested_loop)
                                key_data_loop.clear()
                                val_data_loop.clear()
                        """
                        
                            #pass                            
                            #print(k,"---------",z)
                            #print("--------K------------")
                    #print(key_data,"---------Z-----------",val_data)
                    
                    secondary_loop = x[i].get("typeProperties",{}).get('activities')
                    if secondary_loop != None:
                        
                        for j in range (len(secondary_loop)):                            
                            loop_dataset_check_dict = secondary_loop[j]
                            
                            loop_dataset_check = loop_dataset_check_dict.get("typeProperties",{}).get('dataset')
                            
                            if loop_dataset_check != None:
                                re_name = loop_dataset_check['referenceName']
                                self.nested_flag = 1
                                
                                #print(re_name,"$$$$")
                                #print("--------------------")
                                #print("--------------------")
                                for l,m in (loop_dataset_check['parameters']).items():
                                    #loop_dataset_check = x[i].get("typeProperties",{}).get('dataset')
                                    if str(type(m)) == "<class 'dict'>":
                                        #pass
                                        #print(l,"---------",m['value'])

                                        split_val = m["value"].split(".")
                                        if split_val[0] == '@pipeline()' and len(split_val) > 1:
                                            if "globalParameters" in split_val:
                                                global_val = split_val[-1]
                                                # global
                                                out_value_l = (global_df[global_val]['value'])
                                                #global_df.get("typeProperties",{}).get('dataset')
                                            else:
                                                out_value_l = split_val[-2] + split_val[-1]
                                        else:
                                            out_value_l = split_val[0]

                                        key_data_loop.append(l)
                                        val_data_loop.append(out_value_l)
                                        #print(out_value_l,"-------L-------------")
                                    else:
                                        #pass
                                        #print(l,"---------",m)
                                        #print("-------L-------------")
                                        #print(l,"++++++++++++++++++")
                                        key_data_loop.append(l)
                                        val_data_loop.append(m)
                                
                                #self.nested_loop_key_responce = []
                                #self.nested_value_after_responce=[]
                                #self.nested_secondary_loop_list_res = []
                                

                                
                                self.nested_secondary_loop_list_res.append(re_name)
                                key_value_after_nestedloop = key_data_loop.copy()
                                value_after_nested_loop = val_data_loop.copy()
                                self.nested_loop_key_responce.append(key_value_after_nestedloop)
                                self.nested_value_after_responce.append(value_after_nested_loop)
                                key_data_loop.clear()
                                val_data_loop.clear()
                                
                    

                                    
                    if i != 0 and link_service_dataset != None:
                    
                        secondary_check = x[i].get("typeProperties",{}).get('dataset')                        
                        if secondary_check != None:
                            self.secondary_loop_flag = 1
                            #print("qqqqqqqqqqqqqqq")
                            #secondary_name = (secondary_check['referenceName']) # reference name
                            #print("--------------------")
                            #print("--------------------")
                            #print(secondary_name,"@@@@@@")
                            #print("--------------------")
                            #print("--------------------")                        
                            link_name = (secondary_check['referenceName']) # reference name this and above are same
                            for r,s in (link_service_dataset['parameters']).items():
                                #pass
                                if str(type(s)) == "<class 'dict'>":
                                    #pass
                                    #print(r,"---------",s['value'])

                                    split_val = s["value"].split(".")
                                    if split_val[0] == '@pipeline()' and len(split_val) > 1:
                                        if "globalParameters" in split_val:
                                            global_val = split_val[-1]
                                            # global
                                            out_value_s = (global_df[global_val]['value'])
                                            #global_df.get("typeProperties",{}).get('dataset')
                                        else:
                                            out_value_s = split_val[-2] + split_val[-1]
                                    else:
                                        out_value_s = split_val[0]
                                    key_data_s.append(r)
                                    val_data_s.append(out_value_s)
                                    #print(out_value_s,"-------R-------------")
                                else:
                                    #pass
                                    #print(r,"---------",s)
                                    #print("-------S-------------")
                                    key_data_s.append(r)
                                    val_data_s.append(s)
                            
                            self.secondary_loop_list_res.append(link_name)
                            key_value_after_loop = key_data_s.copy()
                            value_after_loop = val_data_s.copy()
                            self.loop_key_responce.append(key_value_after_loop)
                            self.value_after_responce.append(value_after_loop)
                            key_data_s.clear()
                            val_data_s.clear()
                             
            
            #if (pipeline_json_file_list[self.pipline_ds_val]) == "Exec_fah_file_config_db_tbl_ap_notebook.json":
            #if unit_test_stat == 1:
            #if unit_test_stat == 1 and (pipeline_json_file_list[self.pipline_ds_val]) != "PL_Shell_Driver_Demand_BY_ES.json":
            if unit_test_stat == 1 and (pipeline_json_file_list[self.pipline_ds_val]) != "PL_Shell_Driver_Demand_BY_ES.json" and file_check_dataset==1:
            #if (pipeline_json_file_list[self.pipline_ds_val]) == "PL_Shell_Driver_Demand_BY_ES.json":
                #print(key_data_s,"-------S-------------",val_data_s)
                #print(key_data_loop,"-------M-------------",val_data_loop)

                #print(key_data,"---------Z-----------",val_data)
                #respnse_parent = {'para_name':key_data,'para_value':val_data}
                #print(respnse_parent)
                #nested_loop_check = any(isinstance(n_l, list) for n_l in self.loop_key_responce)
                #if nested_loop_check ==  True:
                #    print("anoop")
                                
                if self.secondary_loop_flag == 1:
                    respnse_child_loop_pip.append(pip_name)
                    respnse_child_loop_para.append(self.loop_key_responce)
                    respnse_child_loop_ds.append(self.value_after_responce)
                    respnse_child_loop_val.append(self.secondary_loop_list_res)

                    #respnse_child_loop = {'pipeline_name':pip_name,'pipeline_id':pip_name,'para_name':self.loop_key_responce,'para_value':self.value_after_responce,
                    #                    'dataset_name':self.secondary_loop_list_res}
                    
                    #datasource_df1 = pd.DataFrame.from_dict(respnse_child_loop)
                    #print(datasource_df1)
                    #datasource_df1.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'1_JSON.csv',index=False)
                else:
                    respnse_child_loop_pip.append(None)
                    respnse_child_loop_para.append(None)
                    respnse_child_loop_ds.append(None)
                    respnse_child_loop_val.append(None)

                    #respnse_child_loop = {'pipeline_name':None,'pipeline_id':None,'para_name':None,'para_value':None,
                    #                   'dataset_name':None}
                    #datasource_df1 = pd.DataFrame.from_dict(respnse_child_loop)
                #    datasource_df1 = None

                if self.nested_flag == 1:
                    respnse_child_loop_nested_pip.append(pip_name)
                    respnse_child_loop_nested_para.append(self.nested_loop_key_responce)
                    respnse_child_loop_nested_ds.append(self.nested_secondary_loop_list_res)
                    respnse_child_loop_nested_val.append(self.nested_value_after_responce)


                    #respnse_child_nested_loop = {'pipeline_name':pip_name,'pipeline_id':pip_name,'para_name':self.nested_loop_key_responce,'para_value':self.nested_value_after_responce,
                    #                    'dataset_name':self.nested_secondary_loop_list_res}
                    
                    #datasource_df2 = pd.DataFrame.from_dict(respnse_child_nested_loop)

                    #print(datasource_df2)
                    #datasource_df2.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'2_JSON.csv',index=False)
                else:
                    respnse_child_loop_nested_pip.append(None)
                    respnse_child_loop_nested_para.append(None)
                    respnse_child_loop_nested_ds.append(None)
                    respnse_child_loop_nested_val.append(None)

                    #respnse_child_nested_loop = {'pipeline_name':None,'pipeline_id':None,'para_name':None,'para_value':None,
                    #                    'dataset_name':None}
                    #datasource_df2 = pd.DataFrame.from_dict(respnse_child_nested_loop)

                    #datasource_df2 = None

                if self.parent_loop_flag ==1:
                    #self.parent_loop_key_responce.append(key_data)
                    #self.parent_value_after_responce.append(val_data)
                    respnse_child_loop_parent_pip.append(pip_name)
                    respnse_child_loop_parent_para.append(self.parent_loop_key_responce[-1])
                    #respnse_child_loop_parent_ds.append(pip_name)
                    
                    respnse_child_loop_parent_val.append(self.parent_value_after_responce[-1])
                    respnse_child_loop_parent_ds.append(link_name_parent)

                    #print(respnse_child_loop_parent_ds, "-------")

                    #respnse_parent_loop = {'pipeline_name':respnse_child_loop_parent_pip,'pipeline_id':respnse_child_loop_parent_pip,'para_name':respnse_child_loop_parent_para,'para_value':respnse_child_loop_parent_val,
                    #                'dataset_name':respnse_child_loop_parent_ds}
                    
                    #datasource_df3 = pd.DataFrame.from_dict(respnse_parent_loop)

                    #datasource_df3.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'3_JSON.csv',index=False)
                    #print(datasource_df3)
                else:
                    respnse_child_loop_parent_pip.append(None)
                    respnse_child_loop_parent_para.append(None)
                    respnse_child_loop_parent_ds.append(None)
                    respnse_child_loop_parent_val.append(None)
                    
                    #respnse_parent_loop = {'pipeline_name':respnse_child_loop_parent_pip,'pipeline_id':respnse_child_loop_parent_pip,'para_name':respnse_child_loop_parent_para,'para_value':respnse_child_loop_parent_val,
                    #                    'dataset_name':respnse_child_loop_parent_ds}
                    
                    #datasource_df3 = pd.DataFrame.from_dict(respnse_parent_loop)

                    #datasource_df3 = None

                #print( self.secondary_loop_flag,self.nested_flag,self.parent_loop_flag)

                #respnse_child_loop,respnse_child_nested_loop,respnse_parent_loop
                
                """
                if self.secondary_loop_flag == 1  or self.nested_flag == 1 or  self.parent_loop_flag  == 1:
                    self.check_all_stat = 1
                    #empty_df = pd.DataFrame()
                    frames = [datasource_df1, datasource_df2, datasource_df3]
                
                if self.check_all_stat ==1:
                    #print(v)
                    val_con_df = pd.concat(frames)
                    #empty_df = empty_df.append(val_con_df,ignore_index = True)
                    print(val_con_df)
                    #list_v = self.sandeep.append(val_con_df)
                    #print(list_v)

                    #global final_res_anoop
                    #final_res_anoop = list_v

                """
            else:
                #pass

                respnse_child_loop_pip.append(None)
                respnse_child_loop_para.append(None)
                respnse_child_loop_ds.append(None)
                respnse_child_loop_val.append(None)

                respnse_child_loop_nested_pip.append(None)
                respnse_child_loop_nested_para.append(None)
                respnse_child_loop_nested_ds.append(None)
                respnse_child_loop_nested_val.append(None)

                respnse_child_loop_parent_pip.append(None)
                respnse_child_loop_parent_para.append(None)
                respnse_child_loop_parent_ds.append(None)
                respnse_child_loop_parent_val.append(None)

                """
                respnse_child_loop = {'pipeline_name':None,'pipeline_id':None,'para_name':None,'para_value':None,
                                       'dataset_name':None}
                respnse_child_nested_loop = {'pipeline_name':None,'pipeline_id':None,'para_name':None,'para_value':None,
                                        'dataset_name':None}
                respnse_parent_loop = {'pipeline_name':None,'pipeline_id':None,'para_name':None,'para_value':None,
                                        'dataset_name':None}             

            
                """          
            
           
            #print(respnse_child_loop)
                #global final_res_anoop
                #final_res_anoop = self.sandeep
                    #print(final_res_anoop)
            #else:
            #    print(self.sandeep)
                #final_res_anoop = self.sandeep
            #self.sandeep
                    #final_res_anoop = pd.concat(frames)
                #else: = 
                    #final_responce_df = self.final_out_res
                    #anoo.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'ANOOP_JSON.csv',index=False)
                    #print(final_responce_df)
                

                #else:
                #   print("ANNNNNNNNNN")
                #any(isinstance(i, list) for i in b)
                #print(self.loop_key_responce,"*&&&&**********",self.value_after_responce)
                #print(respnse,"*********")          

                
                #@AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

            #"fah_file_config_tbl_ar_balances"
            #if (pipeline_json_file_list[self.pipline_ds_val]) == "Exec_fah_file_config_db_tbl_ap_notebook.json":
            
        except Exception as e:
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print(v,'------ LOGGER - DSPIPLINE------',e)
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print("--------------------")
            print("--------------------")
            
        
        finally:
            global json_count_pipeline
            json_count_pipeline += 1

            #respnse_child_loop = {'pipeline_name':respnse_child_loop_pip,'pipeline_id':respnse_child_loop_pip,'para_name':respnse_child_loop_para,'para_value':respnse_child_loop_val,
            #                           'dataset_name':respnse_child_loop_ds}   
            respnse_child_loop = {'pipeline_name':respnse_child_loop_pip,'pipeline_id':respnse_child_loop_pip,'para_name':respnse_child_loop_para,'para_value':respnse_child_loop_ds,
                                       'dataset_name':respnse_child_loop_val}         
            
            
            respnse_child_nested_loop = {'pipeline_name':respnse_child_loop_nested_pip,'pipeline_id':respnse_child_loop_nested_pip,'para_name':respnse_child_loop_nested_para,'para_value':respnse_child_loop_nested_val,
                                        'dataset_name':respnse_child_loop_nested_ds}
            
            respnse_parent_loop = {'pipeline_name':respnse_child_loop_parent_pip,'pipeline_id':respnse_child_loop_parent_pip,'para_name':respnse_child_loop_parent_para,'para_value':respnse_child_loop_parent_val,
                                        'dataset_name':respnse_child_loop_parent_ds}
            
            return json_count_pipeline,respnse_child_loop,respnse_child_nested_loop,respnse_parent_loop
        #respnse_child_loop,respnse_child_nested_loop,respnse_parent_loop

parent_pip_name_list=[]
class extract_pip_parent_name:
    def __init__(self,default=0):
        self.default_val = default
    def parent_name_extract(self,):
        try:
            #print(self.default_val)
            parent_pip_df = pd.read_json(dir_name_pipeline_json+pipeline_json_file_list[self.default_val])
            pip_name=(pipeline_json_file_list[self.default_val].split(".")[0])
            pip_active_count=(len(parent_pip_df['properties']['activities']))

            #print(pip_name)
            #csv_file_path = CONFIG_OBJ["CSV_DF_PATH"]['path']
            #csv_file_name = CONFIG_OBJ["CSV_DF_PATH"]['pipeline_file_name']
            #csv_df       = pd.read_csv(csv_file_path+csv_file_name)
            unit_test_child_pip = 1
            ll = []
            l_list=[]
            #if pip_name == "8AMand2PMDailyRefresh":
            
            if unit_test_child_pip == 1:
                active_check = (parent_pip_df['properties']['activities'])
                flag=0

                for i in range(pip_active_count):
                    check_child_pip = active_check[i].get("typeProperties",{}).get('pipeline')
                    #check_child_pip = active_check(i)
                    #print(check_child_pip)
                    if check_child_pip != None:
                        flag = 1                        
                        val_pip_name =  check_child_pip.get('referenceName')
                        #filter_data = csv_df.loc[csv_df['Pipeline_Name'] == (val_pip_name)].values.tolist()
                        #filter_id = (filter_data[0][0])
                        ll.append(val_pip_name)
                        set_val= set(ll)
                        anoop = set_val.copy()
                        #print(ll)
                        
                        #set_val = set(anoop)
                        #parent_pip_name_list.append(anoop)
                    #else:
                    #    parent_pip_name_list.append('None')
                if flag ==1:
                    parent_pip_name_list.append(anoop)
                else:
                    parent_pip_name_list.append(None)
                ll.clear()
                #print(parent_pip_name_list)
                    #parent_pip_name_list.clear()
            
            #print(parent_pip_name_list)   
            #avoid_dup = l_list.append(parent_pip_name_list)
            #print(avoid_dup)
                #print(list(avoid_dup))
                
                        #csv_df['parent_name'] = [pip_name if csv_df.loc[csv_df['Pipeline_Name'] == (val_pip_name)] == filter_id else 800 for x in csv_df['Event']] 
                        #if [csv_df['id'] == (filter_id)]:
                        #    print('anoop')
                            #df['parent_name'] = [1500 if x =='Music' else 800 for x in df['Event']]
                       #print(filter_id)
                       #filter1 = csv_df.loc[csv_df['Pipeline_Name'] == ()].values.tolist()

                       #df['parent_name'] = [1500 if x =='Music' else 800 for x in df['Event']]

                       #csv_df['parent_name'] = filter1
                       #print(filter1)

            #link_service_name = link_properties.get("linkedServiceName",{}).get('referenceName')
            """
            df = pd.read_json(dir_name_pipeline_json+pipeline_json_file_list[self.default_val])            
            pip_active_count=(len(df['properties']['activities']))
            pip_folder=((df['properties']['folder']['name'].split("/")[0]))
            pip_name=(pipeline_json_file_list[self.default_val].split(".")[0])
            pipeline_name_list.append(pip_name)
            activities_count_list.append(pip_active_count)
            folder_name_list.append(pip_folder)
            """
        except Exception as e:
            print(e)
        finally:
            
            #print(parent_pip_name_list)
            responce_child = {'child_pipleine_name':parent_pip_name_list}
            global json_count_pipeline
            json_count_pipeline += 1

            return json_count_pipeline,responce_child
#anoop = 21 ##########################

First_load =1  
if __name__ == '__main__' and input_variable == 2:
    while len(pipeline_json_file_list) != json_count_pipeline and len(pipeline_json_file_list) !=0 and First_load==1:
          
        json_exe = extract_data_json(json_count_pipeline)
        result,response_val = json_exe.pipline_exe()
        if len(pipeline_json_file_list) == result:
            pipeline_df = pd.DataFrame.from_dict(response_val)
            #for k in range (len(pipeline_df)):
            #df['is_rich_method1'] = np.where(df['salary']>=50, 'yes', 'no')

            for val_id in pipeline_df.index:
                cc = pipeline_df['Child_pipiline_names'][val_id]
                parent_name_csv= pipeline_df['Pipeline_Name'][val_id]
                if cc != None:
                    dd=1
                    #if parent_name_csv == "8AMand2PMDailyRefresh":
                    #if parent_name_csv == "fah_file_config_tbl_ahcs_details":
                        
                    if dd == 1:
                        check_list_parent = []
                        for dict_i in cc:
                            #df.insert(0,'name_of_column',value)
                            #filter1 = pipeline_df.loc[pipeline_df['Pipeline_Name'] == (parent_name_csv)].values.tolist()
                            filter1 = pipeline_df.loc[pipeline_df['Pipeline_Name'] == (dict_i)]
                            
                            index_id_val = pipeline_df.loc[pipeline_df['Pipeline_Name'] == (dict_i)].index.tolist()
                            #print( index_id_val[0] )
                            
                            csv_values = pipeline_df.loc[pipeline_df['Pipeline_Name'] == (dict_i)].values.tolist()
                            #print(csv_values)
                            #exit()
                            if (csv_values[0][4]) != None:
                                check_list_parent.append((csv_values[0][4]))
                                check_list_parent.append(parent_name_csv)
                            else:
                                check_list_parent.append(parent_name_csv)
                            
                            if len(check_list_parent) != 0 and check_list_parent[0]!=None:
                                list_str = (",".join(check_list_parent))
                            else:
                                list_str = None
                            #print(list_str)
                            #exit()
                            using_index=pipeline_df.iloc[index_id_val[0],4]=list_str
                            #print((csv_values[0][4]))
                            #exit()
                            #https://www.c-sharpcorner.com/article/add-assign-and-modify-values-in-dataframe/
                            #pip_id = ((filter1[0][0]))# id value
                            #using_index=pipeline_df.iloc[64,4]=parent_name_csv
                            #pipeline_df.insert(0,'parent_pipiline_name',parent_name_csv)
                            #pipeline_df['is_rich_method1'] = np.where(pipeline_df['Pipeline_Name']==dict_i, parent_name_csv,'No')
                            #if pipeline_df['Pipeline_Name'] == dict_i:
                            #    print(('a'))
            #filter1 = pipeline_df.loc[pipeline_df['Pipeline_Name'] == ()].values.tolist()
            #filter11 = pipeline_df.loc[pipeline_df['Pipeline_Name'] == ("PL_AAS_REFRESH_SUBMIT")
            #filter11 = pipeline_df.loc[pipeline_df['Pipeline_Name'] == ("fah_file_config_tbl_ahcs_details")]
            
            #print((filter11))
            #PL_AAS_REFRESH_SUBMIT
            #exit()

            pipeline_df["id"] = pipeline_df.index + 1 #add id as index in dataframe
            # id replace postion as first col in dataframe

            pipeline_df.set_index(pipeline_df.columns[-1], inplace=True)
            pipeline_df.reset_index(inplace=True)
            
            if os.path.exists(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPLEINE_JSON.csv'):
                location_link_pipline = CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']
                path_remove_pipline = os.path.join(location_link_pipline, "PIPLEINE_JSON.csv")
                os.remove(path_remove_pipline)

            pipeline_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPLEINE_JSON.csv',index=False)            
            
            First_load=2
            print("-------------------------PIPILINE------ DONE--------------------")
            break


### trigger loggic:

if __name__ == '__main__' and First_load == 2 and input_variable == 2:
    while len(trigger_json_file_list) != json_count_trigger and len(trigger_json_file_list) !=0:
          
        json_exe = trigger_export(json_count_trigger)
        trigger_result,response_val_trigger,inter_response_df,para_response_df = json_exe.trigger_exe()
        #break 
        if len(trigger_json_file_list) == trigger_result:
            trigger_df = pd.DataFrame.from_dict(response_val_trigger)
            #trigger_df.set_index(pipeline_df.columns[-1], inplace=True)
            #trigger_df.reset_index(inplace=False)
            if os.path.exists(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'TRIGGER_JSON.csv'):
                location_link_trigger = CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']
                path_remove_trigger = os.path.join(location_link_trigger, "TRIGGER_JSON.csv")
                os.remove(path_remove_trigger)

            trigger_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'TRIGGER_JSON.csv',index=False)

            pipiline_trigger_df = pd.DataFrame.from_dict(inter_response_df)
            pipiline_trigger_df["id"] = pipiline_trigger_df.index + 1 #add id as index in dataframe
            pipiline_trigger_df.set_index(pipiline_trigger_df.columns[-1], inplace=True)
            pipiline_trigger_df.reset_index(inplace=True)

            if os.path.exists(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPILINE_TRIGGER_JSON.csv'):
                location_pipline_trigger = CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']
                path_remove_trigger_pip = os.path.join(location_pipline_trigger, "PIPILINE_TRIGGER_JSON.csv")
                os.remove(path_remove_trigger_pip)

            pipiline_trigger_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPILINE_TRIGGER_JSON.csv',index=False)

            para_df = pd.DataFrame.from_dict(para_response_df)
            para_df["id"] = para_df.index + 1 #add id as index in dataframe
            para_df.set_index(para_df.columns[-1], inplace=True)
            para_df.reset_index(inplace=True)

            if os.path.exists(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PARA_TRIGGER_JSON.csv'):
                location_trigger_para = CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']
                path_remove_trigger_para = os.path.join(location_trigger_para, "PARA_TRIGGER_JSON.csv")
                os.remove(path_remove_trigger_para)

            para_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PARA_TRIGGER_JSON.csv',index=False)


            #pipeline_df["id"] = pipeline_df.index + 1 #add id as index in dataframe
            # id replace postion as first col in dataframe
            
            #pipeline_df.set_index(pipeline_df.columns[-1], inplace=True)
            #pipeline_df.reset_index(inplace=True)
            #pipeline_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPLEINE_JSON.csv')            
            #print(inter_response_df)
            print("-----------TRIGGER - TRIGGER_PIPIPLINE-- TRIGGER PARA --------------")
            print("-----------hELLO TRIGGER - TRIGGER_PIPIPLINE-- TRIGGER PARA Export Done-------------")
            #First_load=2
            First_load = 3
            break



##############

if __name__ == '__main__' and input_variable == 2:
    
    while len(link_json_file_list) != json_count_link_service and len(link_json_file_list) !=0 and First_load==3:

        json_link_service_exe = link_service(json_count_link_service)
        result,response_link_service_val,response_link_service_para_val = json_link_service_exe.link_service_export()
        if len(link_json_file_list) == result:
            link_service_df = pd.DataFrame.from_dict(response_link_service_val)

            #link_service_df["id"] = pipeline_df.index + 1 #add id as index in dataframe
            # id replace postion as first col in dataframe

            #pipeline_df.set_index(pipeline_df.columns[-1], inplace=False)
            #pipeline_df.reset_index(inplace=False)
            link_service_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'LINK_SERVICE_JSON.csv',index=False)            
            #print(pipeline_df)
            ########## parametr dataframe#################
            link_service_df = pd.DataFrame.from_dict(response_link_service_para_val)

            link_service_df["id"] = link_service_df.index + 1 #add id as index in dataframe
            # id replace postion as first col in dataframe

            link_service_df.set_index(link_service_df.columns[-1], inplace=True)
            link_service_df.reset_index(inplace=True)

            if os.path.exists(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'LINK_SERVICE_PARAMETER.csv'):
                location_link_serv = CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']
                path_remove_link_serv = os.path.join(location_link_serv, "LINK_SERVICE_PARAMETER.csv")
                os.remove(path_remove_link_serv)         
            
            link_service_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'LINK_SERVICE_PARAMETER.csv',index=False) 


            print("-----------LINK - LINK_SERVICE-- LINK_SERVICE_PARA --------------")
            print("-----------hELLO LINK - LINK_SERVICE-- LINK_SERVICE_PARA Export Done-------------")
            First_load=4
            
            break


### trigger loggic:


if __name__ == '__main__' and First_load == 4 and input_variable == 2:
    while len(datasource_json_file_list) != json_count_datasource and len(datasource_json_file_list) !=0:
        json_exe = datasource(json_count_datasource)
        result_responce,datasource_rep = json_exe.datasource_export()
        if len(datasource_json_file_list) == result_responce:
            #print(datasource_rep)
            
            datasource_df = pd.DataFrame.from_dict(datasource_rep)
            datasource_df["id"] = datasource_df.index + 1 #add id as index in dataframe
            datasource_df.set_index(datasource_df.columns[-1], inplace=True)
            datasource_df.reset_index(inplace=True)

            if os.path.exists(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'DATASOURCE_JSON.csv'):
                location_pipline_datasource = CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']
                path_remove_trigger_ds = os.path.join(location_pipline_datasource, "DATASOURCE_JSON.csv")
                os.remove(path_remove_trigger_ds)

            datasource_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'DATASOURCE_JSON.csv',index=False)

            print("-----------DATASOURCE -- Done --------------")
            
First_load = 4     
if __name__ == '__main__' and First_load == 4 and input_variable == 3:
    while len(pipeline_json_file_list) != json_count_pipeline and len(pipeline_json_file_list) !=0:
        json_exe_ds = pipline_dataset(json_count_pipeline,final_res_anoop)
        result_responce_pipeline_dataset,final_responce_df,datasource_secon,datasource_paraent = json_exe_ds.extract_pipeline_dataset()
        if len(pipeline_json_file_list) == result_responce_pipeline_dataset:
            datasource_df1 = pd.DataFrame.from_dict(final_responce_df)
            datasource_df1 = datasource_df1[datasource_df1['pipeline_name'].notna()]
            #indexNames1 = datasource_df1[ datasource_df1['pipeline_name'] == None ].index
            #datasource_df1.drop(indexNames1 , inplace=True)

            #datasource_df1 = datasource_df1.drop(datasource_df1[datasource_df1.pipeline_name == None].index)

            datasource_df2 = pd.DataFrame.from_dict(datasource_secon)
            datasource_df2 = datasource_df2[datasource_df2['pipeline_name'].notna()]
            #indexNames2 = datasource_df2[ datasource_df2['pipeline_name'] == None ].index
            #datasource_df2.drop(indexNames2 , inplace=True)

            #datasource_df2 = datasource_df2.drop(datasource_df2[datasource_df2.pipeline_name == None].index)


            datasource_df3 = pd.DataFrame.from_dict(datasource_paraent)
            datasource_df3 = datasource_df3[datasource_df3['pipeline_name'].notna()]
            #indexNames3 = datasource_df3[ datasource_df3['pipeline_name'] == None ].index
            #datasource_df3.drop(indexNames3 , inplace=True)

            #datasource_df3 = datasource_df3.drop(datasource_df3[datasource_df3.pipeline_name == None].index)

            final_dataframe_concant = [datasource_df3,datasource_df1, datasource_df2]
            result_final_df_concant = pd.concat(final_dataframe_concant)
            result_final_df_concant = result_final_df_concant.reset_index(drop=True)
            #result_final_df_concant = result_final_df_concant.drop(result_final_df_concant[result_final_df_concant.pipeline_name == None].index)
            #print(result_final_df_concant)
            #pip_set_df = pd.DataFrame.from_dict(final_responce_df)
            result_final_df_concant["id"] = result_final_df_concant.index + 1 #add id as index in dataframe
            result_final_df_concant.set_index(result_final_df_concant.columns[-1], inplace=True)
            result_final_df_concant.reset_index(inplace=True)

            if os.path.exists(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPELINE_DATASET_RESULT.csv'):
                location_pipline_dataset = CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']
                path_remove_pip_set_csv = os.path.join(location_pipline_dataset, "DATASOURCE_JSON.csv")
                os.remove(path_remove_pip_set_csv)

            result_final_df_concant.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPELINE_DATASET_RESULT.csv',index=False)
            #print(pip_set_df)
            print("-----------PIPELINE_DATASET_RESULT -- Done --------------")


First_load = 5

if __name__ == '__main__' and input_variable == 4:
    while len(pipeline_json_file_list) != json_count_pipeline and len(pipeline_json_file_list) !=0 and First_load==5:
        json_exe_pip_parent = extract_pip_parent_name(json_count_pipeline)
        result,child_pip_name = json_exe_pip_parent.parent_name_extract()
        if len(pipeline_json_file_list) == result:
            child_pip_df = pd.DataFrame.from_dict(child_pip_name)
            
            csv_file_path = CONFIG_OBJ["CSV_DF_PATH"]['path']
            csv_file_name = CONFIG_OBJ["CSV_DF_PATH"]['pipeline_file_name']
            csv_df       = pd.read_csv(csv_file_path+csv_file_name)
            frames_child_pip = [csv_df, child_pip_df]
            val_con_df = pd.concat([csv_df, child_pip_df], axis=1, join='inner')

            #val_con_df = pd.concat(frames_child_pip)
            """
            frames = [datasource_df1, datasource_df2, datasource_df3]
                
                if self.check_all_stat ==1:
                    #print(v)
                    val_con_df = pd.concat(frames)
            """
            #csv_df       = pd.read_csv(csv_file_path+csv_file_name)
            print(child_pip_df)
            val_con_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'CHILD.csv',index=False)

"""
pip_set_df = pd.DataFrame.from_dict(final_responce_df)
pip_set_df["id"] = pip_set_df.index + 1 #add id as index in dataframe
pip_set_df.set_index(pip_set_df.columns[-1], inplace=True)
pip_set_df.reset_index(inplace=True)

if os.path.exists(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPELINE_DATASET_RESULT.csv'):
location_pipline_dataset = CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']
path_remove_pip_set_csv = os.path.join(location_pipline_dataset, "DATASOURCE_JSON.csv")
os.remove(path_remove_pip_set_csv)

#pip_set_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPELINE_DATASET_RESULT.csv',index=False)
#print(pip_set_df)

"""


#print("---",result_responce)

"""
while len(trigger_json_file_list) != json_count_trigger and len(trigger_json_file_list) !=0:

json_exe = trigger_export(json_count_trigger)
trigger_result,response_val_trigger,inter_response_df,para_response_df = json_exe.trigger_exe()
#break 
if len(trigger_json_file_list) == trigger_result:
trigger_df = pd.DataFrame.from_dict(response_val_trigger)
#trigger_df.set_index(pipeline_df.columns[-1], inplace=True)
#trigger_df.reset_index(inplace=False)
if os.path.exists(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'TRIGGER_JSON.csv'):
location_link_trigger = CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']
path_remove_trigger = os.path.join(location_link_trigger, "TRIGGER_JSON.csv")
os.remove(path_remove_trigger)

trigger_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'TRIGGER_JSON.csv',index=False)

pipiline_trigger_df = pd.DataFrame.from_dict(inter_response_df)
pipiline_trigger_df["id"] = pipiline_trigger_df.index + 1 #add id as index in dataframe
pipiline_trigger_df.set_index(pipiline_trigger_df.columns[-1], inplace=True)
pipiline_trigger_df.reset_index(inplace=True)

if os.path.exists(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPILINE_TRIGGER_JSON.csv'):
location_pipline_trigger = CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']
path_remove_trigger_pip = os.path.join(location_pipline_trigger, "PIPILINE_TRIGGER_JSON.csv")
os.remove(path_remove_trigger_pip)

pipiline_trigger_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPILINE_TRIGGER_JSON.csv',index=False)

para_df = pd.DataFrame.from_dict(para_response_df)
para_df["id"] = para_df.index + 1 #add id as index in dataframe
para_df.set_index(para_df.columns[-1], inplace=True)
para_df.reset_index(inplace=True)

if os.path.exists(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PARA_TRIGGER_JSON.csv'):
location_trigger_para = CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']
path_remove_trigger_para = os.path.join(location_trigger_para, "PARA_TRIGGER_JSON.csv")
os.remove(path_remove_trigger_para)

para_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PARA_TRIGGER_JSON.csv',index=False)


#pipeline_df["id"] = pipeline_df.index + 1 #add id as index in dataframe
# id replace postion as first col in dataframe

#pipeline_df.set_index(pipeline_df.columns[-1], inplace=True)
#pipeline_df.reset_index(inplace=True)
#pipeline_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPLEINE_JSON.csv')            
#print(inter_response_df)
print("-----------TRIGGER - TRIGGER_PIPIPLINE-- TRIGGER PARA --------------")
print("-----------hELLO TRIGGER - TRIGGER_PIPIPLINE-- TRIGGER PARA Export Done-------------")
#First_load=2
First_load = 6
if First_load ==6:
exit()
break
"""
################

"""
while len(pipeline_json_file_list) != json_count_pipeline and len(pipeline_json_file_list) !=0:

json_exe = extract_data_json(json_count_pipeline)
result,response_val = json_exe.pipline_exe()
if len(pipeline_json_file_list) == result:
pipeline_df = pd.DataFrame.from_dict(response_val)
pipeline_df["id"] = pipeline_df.index + 1 #add id as index in dataframe
# id replace postion as first col in dataframe
pipeline_df.set_index(pipeline_df.columns[-1], inplace=True)
pipeline_df.reset_index(inplace=True)
#pipeline_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPLEINE_JSON.csv')            
print(pipeline_df)
First_load=2
break
""" 
"""  
exe_ETL = etl_load_csv(load_count)
result,load_response_message = exe_ETL.data_insert_mysql()
if len(csv_file_list) == result:
print(load_response_message)
break
print(load_response_message)
"""

#json_exe.extract_data()

