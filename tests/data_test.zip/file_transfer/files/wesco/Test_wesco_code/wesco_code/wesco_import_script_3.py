"""
Author/File Name/Developer   : Xoriant team / wesco_import_script.py/Anoop
Project Description: ETL Script to import the CSV data in mySQL db using python
Deployement method :
Git repo           :
"""
from configparser import ConfigParser
import pandas as pd
import mysql.connector
from sqlalchemy import create_engine
import datetime
import os
import json


#setup config file 
CONFIG_OBJ = ConfigParser()
CONFIG_OBJ.read("./config.ini")

"""
Global config -  varibale to automate load the csv in mysql db
"""
#csv file location
dir_name        = CONFIG_OBJ["FILE_PATH"]['file_location']
csv_file_list   = [file for file in os.listdir(dir_name)] # List of csv file name in above location
load_count      = 0
anoop           = 2 ###############

#db connecttion:
connection_string   = CONFIG_OBJ["DB_CONN_LOCAL"]['db_env']
engine              = create_engine(connection_string)
engine.connect()

# Load time cal
process_start_time = datetime.datetime.now()
# custome schema build table name
custome_table_list = CONFIG_OBJ["CUSTOM_SCHEMA"]['table_name']

class etl_load_csv:
    
    def __init__(self,default=0):
        self.default_val = default
        # condition to check for custome_schema 
        if(csv_file_list[default].split('.')[0]) in custome_table_list:
            self.schema_flag = 1
        else:
            self.schema_flag = 0    
    
    def data_insert_mysql(self,):
        """
        Fetch CSV-file and covert data as dataframe and load in mysql db
        Args:
            request: CSV file as a agrs fetch from the location path
        Return:
            Logg message of data table values (toal record value in db and csv file record count)
        """
        try:
            # Count csv file in location and load data in mysql one by one index in list
            global load_count
            load_count += 1
            #read csv file as dataframe
            dataframe       = pd.read_csv(dir_name+csv_file_list[self.default_val])
            dataframe["id"] = dataframe.index + 1 #add id as index in dataframe
            # id replace postion as first col in dataframe
            dataframe.set_index(dataframe.columns[-1], inplace=True)
            dataframe.reset_index(inplace=True)        

            #Drop table and load data in mysql table
            if self.schema_flag == 0:
                with engine.begin() as connection:
                    dataframe.to_sql(csv_file_list[self.default_val].split('.')[0].lower(), con=connection,
                                     if_exists='replace', index=False)
            else:
                # Custome Schema build to made in else part
                pass

            # table load time
            tbl_load_time = datetime.datetime.now()            
            print("---------------", csv_file_list[self.default_val].split('.')[0],"---------------",self.default_val)
            msg_dict = {"record_count":dataframe['id'].count(),'process_start_time':process_start_time,
                        'process_end_time':tbl_load_time,'table_name':csv_file_list[self.default_val].split('.')[0]}

            load_response_message = {'version':'1.0', 'status':'Completed', 'message':msg_dict}
        except Exception as e:

            load_response_message = {'version':'1.0', 'status':'Error', 'message':e,
                                     'table_name':csv_file_list[self.default_val].split('.')[0]}
        finally:

            return load_count,load_response_message

"""
While Condition: This will load all data from csv file's from the location 
Auto load all csv files data in above location 
"""    
while len(csv_file_list) != load_count and len(csv_file_list) !=0 and anoop==1:    
    exe_ETL = etl_load_csv(load_count)
    result,load_response_message = exe_ETL.data_insert_mysql()
    if len(csv_file_list) == result:
        print(load_response_message)
        break
    print(load_response_message)
print('Hello-ETL  ------********------  You Completed')


"""
python class to build extract data from json file

"""

"""
Global variable declaration location path
"""
#csv file location
json_dir_name    = CONFIG_OBJ["JSON_FILE_PATH"]['json_file_location']
json_file_name = '8AMand2PMDailyRefresh.json'

#pipeline global static @para

dir_name_pipeline_json       = CONFIG_OBJ["JSON_FILE_PATH"]['pipeline_json_file_location']
pipeline_json_file_list   = [file for file in os.listdir(dir_name_pipeline_json)]
json_count_pipeline = 0

pipeline_name_list=[]
activities_count_list = []
folder_name_list=[]

#trigger global static @para

dir_name_trigger_json       = CONFIG_OBJ["JSON_FILE_PATH"]['trigger_json_file_location']
trigger_json_file_list   = [file for file in os.listdir(dir_name_trigger_json)]
json_count_trigger = 0

trigger_id_list=[]
trigger_name_list = []
trtigger_type_list=[]
trigger_details_list = []

class extract_data_json:
    def __init__(self,default=0):
        self.default_val = default
    def iter_val_list(self,list_val):
        try:
            if len(list_val) != 0:
                for z_jsonKey in list_val:
                    if str(type(z_jsonKey)) == "<class 'dict'>":
                        self.iter_val_dict(z_jsonKey)
                    if str(type(z_jsonKey))== "<class 'list'>":
                        self.iter_val_list(z_jsonKey)
                    if str(type(z_jsonKey)) == "<class 'str'>":                    
                        print(z_jsonKey,":::LLLLLL:--->",(z_jsonKey))
        except Exception as e:
            print('LOGGER-ERROR:iter_val_list ',e)
    def iter_val_dict(self,dict_val):
        try:
            for k_jsonKey in dict_val:
                if str(type(dict_val[k_jsonKey])) == "<class 'list'>":
                    #print('DDDDDDDD',dict_val[k_jsonKey])
                    self.iter_val_list(dict_val[k_jsonKey])
                if str(type(dict_val[k_jsonKey])) == "<class 'dict'>":
                    self.iter_val_dict(dict_val[k_jsonKey])
                if str(type(dict_val[k_jsonKey])) == "<class 'str'>":                    
                    #if k_jsonKey == 'type':
                        #print(k_jsonKey,":",(dict_val[k_jsonKey]))
                    #pass
                    print(k_jsonKey,":::SSSSSSSSS:--->",(dict_val[k_jsonKey]))
        except Exception as e:
            print('LOGGER-ERROR:iter_val_dict ',e)

    def json_iter_next(self,nxt,data):

        try:
            json_resource =  data
            for i_jsonKey in json_resource:
                if i_jsonKey == 'type':
                    if json_resource[i_jsonKey] != 'Microsoft.DataFactory/factories/pipelines':
                        print(json_resource[i_jsonKey])
                if str(type(json_resource[i_jsonKey]))== "<class 'dict'>":
                    self.iter_val_dict(json_resource[i_jsonKey])
                    #return aaa
                if str(type(json_resource[i_jsonKey])) == "<class 'str'>":
                    print('qqqqq',json_resource[i_jsonKey])
        except Exception as e:
            print('LOGGER-ERROR:json_iter_next ',e)
 
    def extract_data(self,):
        """
        Extract data from json file data will be order based on pipeline and trigger function  
        Args:
            request: JSON file path or file 
        Return:
            dataframe will retrive form the json file 
        """
        try:
            #laod to json and convert to dataframe to avoid mixing dicts with non-series error           
            data = json.load(open(json_dir_name+json_file_name))
            data_len = len(data["resources"])
            
            
            for i in range(data_len):
                #pass
                print("---------------",i,"------------------")             
                #self.json_iter_next(data_len,data["resources"][i])
                #print((data["resources"][i]["properties"]['activities'][0]['type']))
            
        except Exception as e:
            print('logger',e)
        finally:
            pass
    

    def pipline_exe(self,):
        """
        Extract data from json file data will be order based on pipeline and trigger function  
        Args:
            request: JSON file path or file 
        Return:
            dataframe will retrive form the json file 
        """
        #print()
        
        try:            
            df = pd.read_json(dir_name_pipeline_json+pipeline_json_file_list[self.default_val])            
            pip_active_count=(len(df['properties']['activities']))
            pip_folder=((df['properties']['folder']['name'].split("/")[0]))
            pip_name=(pipeline_json_file_list[self.default_val].split(".")[0])
            pipeline_name_list.append(pip_name)
            activities_count_list.append(pip_active_count)
            folder_name_list.append(pip_folder)
            
            response_val={'Pipeline_Name':pipeline_name_list,'Activities_Count':activities_count_list,'Folder_Name':folder_name_list,
                          'Trigger_status':0,'Trigger_id':0}
            
            global json_count_pipeline
            json_count_pipeline += 1

            if len(pipeline_json_file_list) == json_count_pipeline:
                #print(response_val)
                return json_count_pipeline,response_val
            else:
                #pass
                return json_count_pipeline,response_val
                #print('response_val')
        except Exception as e:            
            print(e)

#intermediate table
pipline_id_val =[] 
trigger_id_val = []
#parameter:
para_name_list=[]
para_val_list=[]
pipline_id_para=[]
trigger_id_pra=[]

class trigger_export():
    def __init__(self,default=0):
        self.trigger_val = default
        self.inter_response_df = {}
        self.para_response_df={}
        #self.json_count_pipeline = 
    def trigger_exe(self,):

        """
        Extract data from json file data will be order based on pipeline and trigger function  
        Args:
            request: JSON file path or file 
        Return:
            dataframe will retrive form the json file 
        """
        #print()
        
        try:
            #pp = super().pipline_exe()
            #print(pp)
            trigger_df = pd.read_json(dir_name_trigger_json+trigger_json_file_list[self.trigger_val])
            #print(trigger_df['properties']['type'])
            #print(trigger_df['name']['annotations'])
            index_val = self.trigger_val +1
            v =trigger_json_file_list[self.trigger_val]
            #print(index_val,"------",self.trigger_val)
            csv_file_path = CONFIG_OBJ["CSV_DF_PATH"]['path']
            csv_file_name = CONFIG_OBJ["CSV_DF_PATH"]['pipeline_file_name']

            """
            #if len((trigger_df['properties']['pipelines'])) != 0:
            if len((trigger_df['properties']['pipelines'])) > 1:

                for i in (((trigger_df['properties']['pipelines']))):
                    #x = car.get("model")
                    par_val = i.get('parameters')
                    if par_val != None:
                        for j in par_val:
                            print('para_name',j)
                            print('para_val',par_val[j])

                    print('---',par_val)
                    #print(i['pipelineReference']['referenceName']['anoop'])
                #print(((trigger_df['properties']['pipelines'])))
                exit()
            """
            #Inter mediate table pipline and trigger and parameter
            pipeline_key_check = ((trigger_df['properties']))
            pipline_stat = pipeline_key_check.get("pipelines")
            if pipline_stat != None:
                if len((trigger_df['properties']['pipelines'])) != 0:
                    #print(1)
                    csv_df       = pd.read_csv(csv_file_path+csv_file_name,index_col=0)
                    #print(df.to_csv(index=False))
                    #filter1 = csv_df["Pipeline_Name"]==trigger_df['properties']['pipelines']
                    
                    for i in (((trigger_df['properties']['pipelines']))):
                        #filter1 = csv_df["Pipeline_Name"]== (i['pipelineReference']['referenceName'])
                        #csv_df.set_index(csv_df.columns[-1], inplace=False)
                        #csv_df.reset_index(inplace=False)
                        filter1 = csv_df.loc[csv_df['Pipeline_Name'] == (i['pipelineReference']['referenceName'])].values.tolist()
                        pip_id = ((filter1[0][0]))# id value                        
                        pipline_id_val.append(pip_id)
                        trigger_id_val.append(index_val)

                        # parameter value stroe:
                        par_val = i.get('parameters')
                        if par_val != None:
                            for j in par_val:
                                para_name_list.append(j)
                                para_val_list.append(par_val[j])
                                pipline_id_para.append(pip_id)
                                trigger_id_pra.append(index_val)
                            self.para_response_df = {"pipline_id":pipline_id_para,"trigger_id":trigger_id_pra,'para_name':para_name_list,
                                                      "para_val":para_val_list}
                    self.inter_response_df = {"pipline_id":pipline_id_val,"trigger_id":trigger_id_val}            
            
            if trigger_df['properties']['type'] == 'ScheduleTrigger':
                #pass
                
                #""
                trigger_type_val = (trigger_df['properties']['type'])
                trigger_name_val=(trigger_df['name']['annotations'])
                trigger_details_val=(trigger_df['properties']['typeProperties']['recurrence'])
                trigger_id_list.append(index_val)
                trigger_name_list.append(trigger_name_val)
                trtigger_type_list.append(trigger_type_val)
                trigger_details_list.append(trigger_details_val)
                
                #response_val_trigger = {'id':trigger_id_list,'Trigger_name':trigger_name_list,'Trigger_type':trtigger_type_list,
                #                        'Trigger_details':trigger_details_list}
                
                
                
                #print(trigger_df['properties']['type'])
                #print(trigger_df['name']['annotations'])
                #print(trigger_df['properties']['typeProperties']['recurrence'])
            else:
                #pass
                
                if trigger_df['properties']['type'] == 'BlobEventsTrigger':
                    trigger_type_val = (trigger_df['properties']['type'])
                    trigger_name_val=(trigger_df['name']['annotations'])
                    #trigger_details_val=(trigger_df['properties']['typeProperties']['recurrence'])
                    path_dir_name = (trigger_df['properties']['typeProperties']['blobPathBeginsWith'].split('/')[2:])

                    path_dir_name_end_check = (trigger_df['properties']['typeProperties'])
                    end_path_val = path_dir_name_end_check.get("blobPathEndsWith") # check null value

                    path_dir_name_join = ("/".join(path_dir_name))
                    tri_detils = {"BlobEvents_StorageAccName":(trigger_df['properties']['typeProperties']['scope'].split('/')[-1]),
                        "BlobEvents_StorageContainerName":(trigger_df['properties']['typeProperties']['blobPathBeginsWith'].split('/')[1]),
                        "BlobEvents_BlobPathBegin":path_dir_name_join,"BlobEvents_BlobPathEnd":end_path_val}
                    
                    trigger_id_list.append(index_val)
                    trigger_name_list.append(trigger_name_val)
                    trtigger_type_list.append(trigger_type_val)
                    trigger_details_list.append(tri_detils)
                else:
                    trigger_type_val = (trigger_df['properties']['type'])
                    trigger_name_val=(trigger_df['name']['annotations'])
                    tri_detils = None

                    trigger_id_list.append(index_val)
                    trigger_name_list.append(trigger_name_val)
                    trtigger_type_list.append(trigger_type_val)
                    trigger_details_list.append(tri_detils)
                
                #print('pasaas')
                #exit()

                """
                #print(trigger_df)
                print(trigger_df['name']['annotations'])
                print(trigger_df['properties']['type'])
                print(trigger_df['properties']['typeProperties']['scope'].split('/')[-1])
                
                print(trigger_df['properties']['typeProperties']['blobPathBeginsWith'].split('/')[1])
                print(trigger_df['properties']['typeProperties']['blobPathBeginsWith'].split('/')[2:])
                qq = (trigger_df['properties']['typeProperties']['blobPathBeginsWith'].split('/')[2:])
                print(trigger_df['properties']['typeProperties']['blobPathEndsWith'])
                print("/".join(qq))
                 
                exit()
                """

            response_val_trigger = {'id':trigger_id_list,'Trigger_name':trigger_name_list,
                                    'Trigger_type':trtigger_type_list,'Trigger_details':trigger_details_list}
                
            #pip_active_count=(len(df['properties']['activities']))
            #pip_folder=((df['properties']['folder']['name'].split("/")[0]))
            #pip_name=(pipeline_json_file_list[self.default_val].split(".")[0])
            #pipeline_name_list.append(pip_name)
            #activities_count_list.append(pip_active_count)
            #folder_name_list.append(pip_folder)
            
            #response_val={'Pipeline_Name':pipeline_name_list,'Activities_Count':activities_count_list,'Folder_Name':folder_name_list,
                          #'Trigger_status':0,'Trigger_id':0}
            #print("rtyuioiuytr",self.trigger_val)
            
            global json_count_trigger
            json_count_trigger += 1
            #print(response_val_trigger)
            #exit()
            
            #response_val = {'A':1}
            #print(json_count_trigger)
            return json_count_trigger,response_val_trigger,self.inter_response_df,self.para_response_df
            """
            if len(trigger_json_file_list) == json_count_trigger:
                print('response_val')
                return json_count_trigger,response_val
            else:
                #pass
                return json_count_trigger,response_val
                print('response_valq')
            """
        except Exception as e:
            print(v,e)

# LINK SERVICE ############################

dir_name_link_service_json       = CONFIG_OBJ["JSON_FILE_PATH"]['link_service_file_location']
link_json_file_list   = [file for file in os.listdir(dir_name_link_service_json)]
json_count_link_service = 0

id_link_service_list = []
link_service_name_list = []
link_service_type_list = []
azure_stat_list = []
integration_runtime_id_list = []

#parameter value
#para_val_list = []
link_id_list =[]
conn_para_stat_list =[]
file_name_ls = []
para_val = []

integrationRuntime_dict = {"AzureIntRunManaged":1,"ir-email-ddp-eastus-dev":2,"WescoOnPremIntRunTimeDev01":3}

class link_service():
    def __init__(self,default=0):
        self.link_service_val = default
    def link_service_export(self,):
        try:
            #print((self.link_service_val))
            link_service_df = pd.read_json(dir_name_link_service_json+link_json_file_list[self.link_service_val])
            #print(trigger_df['properties']['type'])
            
            #print(link_service_df['name'])
            index_val = self.link_service_val +1
            link_service_name = (link_service_df['name']['annotations'])
            link_service_type = (link_service_df['properties']['type'])
            if link_service_df['properties']['type'] == "AzureKeyVault":
                azure_stat = 1
            else:
                azure_stat = 0
            link_prpoerties = (link_service_df['properties'])
            par_val = link_prpoerties.get('connectVia')
            if par_val != None:
                integration_runtime_id_stat = (integrationRuntime_dict[par_val['referenceName']])
                #print(par_val['referenceName'])
            else:
                integration_runtime_id_stat = 0

            id_link_service_list.append(index_val)
            link_service_name_list.append(link_service_name)
            link_service_type_list.append(link_service_type)
            azure_stat_list.append(azure_stat)
            integration_runtime_id_list.append(integration_runtime_id_stat)

            file_name_json =link_json_file_list[self.link_service_val]
           
            response_link_service_dict = {'id':id_link_service_list,'link_service_name':link_service_name_list,'link_service_type':link_service_type_list,
                                          'azure_state':azure_stat_list,'integration_runtime_id':integration_runtime_id_list}
            
            #link service parameter dict
            properties_typepro_check= (link_service_df['properties']['typeProperties']) #parameters
            properties_check = (link_service_df['properties'])
            par_val = properties_check.get('parameters')
            #print(11)
            conn_par_stat= None
            if par_val != None:
                conn_par_stat=1
                #para_val_list.clear()
                para_val_list = [i for i in par_val.keys()]
                #for i in par_val.keys():
                #    para_val_list.append(i)
                para_name_output = (para_val_list)
            else:
                par_val_co = properties_typepro_check.get('connectionString')
                if par_val_co != None:
                    conn_par_stat=2
                    para_name_output = par_val_co
                else:
                    conn_par_stat=0
                    para_name_output = None
            para_val.append(para_name_output)
            file_name_ls.append(file_name_json)
            conn_para_stat_list.append(conn_par_stat)
            #print(para_name_output)
            response_link_service_para_dict = {"servie_link_id":id_link_service_list,"parameter_name":para_val,"file_name":file_name_ls,
                                               "conn_para_stat":conn_para_stat_list}
            """
            cc_g = ccc.get('connectionString')
            if cc_g != None and r==0:
                par_val = cc_g
            else:
                if r !=1:
                    par_val ='anoop'
            print(par_val)
            """
            """
            if cc == None:
                ccc = (link_service_df['properties'])
                par_val = ccc
            else:
                par_val = cc.get('connectionString')
            print(par_val)
            #exit()
            """

            global json_count_link_service
            json_count_link_service += 1
            #print((json_count_link_service))
            return json_count_link_service,response_link_service_dict,response_link_service_para_dict
        except Exception as e:
            print(file_name_json,"LOgger link", e)

##############

if __name__ == '__main__' and anoop == 2:
    First_load = 3 ##############
    while len(link_json_file_list) != json_count_link_service and len(link_json_file_list) !=0 and First_load==3:

        json_link_service_exe = link_service(json_count_link_service)
        result,response_link_service_val,response_link_service_para_val = json_link_service_exe.link_service_export()
        if len(link_json_file_list) == result:
            link_service_df = pd.DataFrame.from_dict(response_link_service_val)

            #link_service_df["id"] = pipeline_df.index + 1 #add id as index in dataframe
            # id replace postion as first col in dataframe

            #pipeline_df.set_index(pipeline_df.columns[-1], inplace=False)
            #pipeline_df.reset_index(inplace=False)
            #link_service_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'LINK_SERVICE_JSON.csv')            
            #print(pipeline_df)
            ########## parametr dataframe#################
            link_service_df = pd.DataFrame.from_dict(response_link_service_para_val)

            link_service_df["id"] = link_service_df.index + 1 #add id as index in dataframe
            # id replace postion as first col in dataframe

            link_service_df.set_index(link_service_df.columns[-1], inplace=True)
            link_service_df.reset_index(inplace=True)
            link_service_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'LINK_SERVICE_PARAMETER.csv') 
            print("23456")
            First_load=4
            break
################

anoop = 5 ##########################
First_load =1  
if __name__ == '__main__' and anoop == 2:
    while len(pipeline_json_file_list) != json_count_pipeline and len(pipeline_json_file_list) !=0 and First_load==1:
          
        json_exe = extract_data_json(json_count_pipeline)
        result,response_val = json_exe.pipline_exe()
        if len(pipeline_json_file_list) == result:
            pipeline_df = pd.DataFrame.from_dict(response_val)

            pipeline_df["id"] = pipeline_df.index + 1 #add id as index in dataframe
            # id replace postion as first col in dataframe

            pipeline_df.set_index(pipeline_df.columns[-1], inplace=False)
            pipeline_df.reset_index(inplace=False)
            #pipeline_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPLEINE_JSON.csv')            
            #print(pipeline_df)
            First_load=2
            break

### trigger loggic:

if __name__ == '__main__' and First_load == 2 and anoop == 2:
    while len(trigger_json_file_list) != json_count_trigger and len(trigger_json_file_list) !=0:
          
        json_exe = trigger_export(json_count_trigger)
        trigger_result,response_val_trigger,inter_response_df,para_response_df = json_exe.trigger_exe()
        #break 
        if len(trigger_json_file_list) == trigger_result:
            trigger_df = pd.DataFrame.from_dict(response_val_trigger)
            #trigger_df.set_index(pipeline_df.columns[-1], inplace=True)
            trigger_df.reset_index(inplace=False)
            trigger_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'TRIGGER_JSON.csv')

            pipiline_trigger_df = pd.DataFrame.from_dict(inter_response_df)
            pipiline_trigger_df["id"] = pipiline_trigger_df.index + 1 #add id as index in dataframe
            pipiline_trigger_df.set_index(pipiline_trigger_df.columns[-1], inplace=True)
            pipiline_trigger_df.reset_index(inplace=False)
            pipiline_trigger_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPILINE_TRIGGER_JSON.csv')

            para_df = pd.DataFrame.from_dict(para_response_df)
            para_df["id"] = para_df.index + 1 #add id as index in dataframe
            para_df.set_index(para_df.columns[-1], inplace=True)
            para_df.reset_index(inplace=False)
            para_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PARA_TRIGGER_JSON.csv')


            #pipeline_df["id"] = pipeline_df.index + 1 #add id as index in dataframe
            # id replace postion as first col in dataframe
            
            #pipeline_df.set_index(pipeline_df.columns[-1], inplace=True)
            #pipeline_df.reset_index(inplace=True)
            #pipeline_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPLEINE_JSON.csv')            
            #print(inter_response_df)
            print("-----------TRIGGER - TRIGGER_PIPIPLINE-- TRIGGER PARA --------------")
            print("-----------hELLO Export Done-------------")
            #First_load=2
            First_load = 3
            break
    """
    while len(pipeline_json_file_list) != json_count_pipeline and len(pipeline_json_file_list) !=0:
          
        json_exe = extract_data_json(json_count_pipeline)
        result,response_val = json_exe.pipline_exe()
        if len(pipeline_json_file_list) == result:
            pipeline_df = pd.DataFrame.from_dict(response_val)
            pipeline_df["id"] = pipeline_df.index + 1 #add id as index in dataframe
            # id replace postion as first col in dataframe
            pipeline_df.set_index(pipeline_df.columns[-1], inplace=True)
            pipeline_df.reset_index(inplace=True)
            #pipeline_df.to_csv(CONFIG_OBJ["JSON_FILE_PATH"]['store_pipeline_data']+'PIPLEINE_JSON.csv')            
            print(pipeline_df)
            First_load=2
            break
        """ 
    """  
        exe_ETL = etl_load_csv(load_count)
        result,load_response_message = exe_ETL.data_insert_mysql()
        if len(csv_file_list) == result:
            print(load_response_message)
            break
        print(load_response_message)
        """
    
    #json_exe.extract_data()

    