"""
Author/File Name   : Xoriant team / wesco_import_script.py
Project Description: ETL Script to import the CSV data in mySQL db using python
Deployement method :
Git repo           :
"""
from configparser import ConfigParser
import pandas as pd
import mysql.connector
from sqlalchemy import create_engine
import datetime

"""
Global config -  vof db connecttion
"""
csv_file_list = r'C:/Users/nair_an/Documents/wesco_discovery_project/sample_script_and_csv/amar_file/CSV_Exports/mssql_stg_all_objects.csv' #Amar
table_name = "mssql_stg_all_objects" #Amar
db_env = "mysql+mysqlconnector://root:root123@localhost:3306/metadata" #Amar
"""
engine = create_engine(
  'mysql+mysqlconnector://{user}:{password}@{host_name}/{db_name}'.format(
    user='root',
    password=parse.quote('root@1234'),
    host_name='localhost:3306',
    db_name = 'metadata',
  ) 
)
"""
engine              = create_engine(db_env)
engine.connect()
# Load time cal
process_start_time = datetime.datetime.now()
class etl_load_csv:    
    def __init__(self,default=0):
        self.default_val = default
        # condition to check for custome_schema
        self.schema_flag = 0          
    
    def data_insert_mysql(self,):
        """
        Fetch CSV-file and covert data as dataframe and load in mysql db
        Args:
            request: CSV file as a agrs fetch from the location path
        Return:
            Logg message of data table values (toal record value in db and csv file record count)
        """
        try:
            #read csv file as dataframe
            dataframe       = pd.read_csv(csv_file_list)
            dataframe["id"] = dataframe.index + 1 #add id as index in dataframe
            # id replace postion as first col in dataframe
            dataframe.set_index(dataframe.columns[-1], inplace=True)
            dataframe.reset_index(inplace=True)        
            """
            #Drop table and load data in mysql table
            if self.schema_flag == 0:
                with engine.begin() as connection:
                    dataframe.to_sql(table_name.lower(),con=connection,if_exists='replace', index=False)
            else:
                # Custome Schema build to made in else part
                pass
            """
            # table load time
            tbl_load_time = datetime.datetime.now()
            len_df = len(dataframe)
            #print(len_df)
            #print(dataframe.loc[0:20])
            load_count = 0
            while len_df <= load_count:
                index_val=load_count
                offset_df =  (dataframe.loc[index_val:50])
                if self.schema_flag == 0:
                    with engine.begin() as connection:
                        offset_df.to_sql(table_name.lower(),con=connection,if_exists='append', index=False)
                else:
                    # Custome Schema build to made in else part
                    pass
                load_count = index_val+50

            #for i in 
            #X_pca.loc[i]
            exit()            
            #print("---------------", csv_file_list[self.default_val].split('.')[0],"---------------",self.default_val)
            msg_dict = {"record_count":dataframe['id'].count(),'process_start_time':process_start_time,
                        'process_end_time':tbl_load_time,'table_name':table_name}

            load_response_message = {'version':'1.0', 'status':'Completed', 'message':msg_dict}
        except Exception as e:

            load_response_message = {'version':'1.0', 'status':'Error', 'message':e,
                                     'table_name':table_name}
        finally:

            return load_response_message
"""
Call the function to laod
"""   
exe_ETL = etl_load_csv()
load_response_message = exe_ETL.data_insert_mysql()
print(load_response_message)
print('Hello-ETL  ------********------  You Completed')