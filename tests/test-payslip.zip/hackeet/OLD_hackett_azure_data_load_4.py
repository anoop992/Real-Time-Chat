"""
Author/File Name   : Xoriant team / hackett_azure_data_load.py
Project Description: Iterate the data from SOPA request and process it load in Azure conatiner 
Deployement method : Job-Scheduler ()
Git repo           :
"""
##### Required Packages - Support ######
from requests import Session
from requests.auth import HTTPBasicAuth
from zeep import Client
from zeep.transports import Transport
from zipfile import ZipFile
from smart_open import open
from pathlib import Path
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
#Azure Functions: Install or Update Core Tool
#Basic
import os
import time
import datetime
import shutil
import tempfile
import pandas as pd


mainfest_temp_folder = tempfile.mkdtemp()
zip_temp_folder = tempfile.mkdtemp()
csv_temp_folder = tempfile.mkdtemp()
print("M",mainfest_temp_folder)
print("Z",zip_temp_folder)
print("C",csv_temp_folder)


#Client Session credentials 
session         = Session()
session.auth    = HTTPBasicAuth('BIAETL','bRE26tS8HcTR')
client          = Client('https://eeih-dev1.fa.us2.oraclecloud.com/idcws/GenericSoapPort?WSDL',transport=Transport(session=session))
ser_request     = client.get_type('ns0:Service')
ser_search      = ser_request(Document= { 'Field': { 'name':'QueryText','_value_1':'dDocTitle <substring> `MANIFEST.MF`'} } , IdcService= 'GET_SEARCH_RESULTS')
req_search      = client.service.GenericSoapOperation(Service=ser_search,webKey='cs')
var_loop_var    =int(req_search['Service']['Document']['Field'][17]['_value_1'])

if var_loop_var < 1:
    # remove temp folder 
    shutil.rmtree(mainfest_temp_folder)
    shutil.rmtree(zip_temp_folder)
    shutil.rmtree(csv_temp_folder) 
    print("No file found as MANIFEST.MF")
    exit()
dID_manifest        =int(req_search['Service']['Document']['ResultSet'][4]['Row'][0]['Field'][0]['_value_1'])
dDocName_manifest   =req_search['Service']['Document']['ResultSet'][4]['Row'][0]['Field'][75]['_value_1']

os.chdir(r"{}".format(str(mainfest_temp_folder)))

## Azure data #Connection Cred 
storage_account_key     = "aUljH5hLSKlLGUhK4lwVyJ5p7MOkUQyCRCQNXlKIRN73ciOkjKBmutg0nliTGDzDuSOn6i3Tfbyi+AStCGBRng=="
storage_account_name    = "oracledatalake"
connection_string       = "DefaultEndpointsProtocol=https;AccountName=oracledatalake;AccountKey=oE0jcds/vXs2a34Jm2+vO8TaukUJIyMPwC8gAYL0JKVjjF8pyFh8c3zv56KtPcWi2NyZ8QEbJa/Q+AStqPcJLA==;EndpointSuffix=core.windows.net"
container_name          = "adfstagedcopytempdata"
"""
User define folder name 
"""
container_folder_name  = "ANOOPVK1"
container_folder_name1 = "bigSize"
ANOOP = 2
class extract_zip_to_csv:

    def __init__(self,):        
        self.flag    = 0
    # Connect to SPA - API
    def download_manifest_and_zip_files(self,):

        """
        Connect to azure credentials and download manifest and zip folder
        Args:
            request: Token & URL path 
        Return:
            store mainfest file and zip file in location
        """
        try:
            """
                Downalod the MANIFEST file in local via SOAP request 
            
            """
            
            var_manifest_id =int(req_search['Service']['Document']['ResultSet'][4]['Row'][0]['Field'][0]['_value_1']) # MANIFEST ID
            ser_download    = ser_request(Document= { 'Field': { 'name':'dID','_value_1':+var_manifest_id} } , IdcService= 'GET_FILE')            
            req_download    = client.service.GenericSoapOperation(Service=ser_download,webKey='cs')
            fileName = req_download['Service']['Document']['File'][0].href
            with open(fileName , 'wb') as f:
                f.write(req_download['Service']['Document']['File'][0].Contents)
            f.close()
            
            """
                Read data from MANIFEST amd pass values to iterate the zip file in local storage

            """                       
            manifest_file_path          = open("{}\MANIFEST.MF".format(mainfest_temp_folder), 'r')
            read_all_line_one_by_one    = manifest_file_path.readlines()
            os.chdir(r"{}".format(str(zip_temp_folder)))
            for line in read_all_line_one_by_one[1:]:
                print(line)
                dID             = int(line.split(";")[1]) # file downlaod id
                ser_download = ser_request(Document= { 'Field': { 'name':'dID','_value_1':+dID} } , IdcService= 'GET_FILE')
                req_download = client.service.GenericSoapOperation(Service=ser_download,webKey='cs')
                fileName     = req_download['Service']['Document']['File'][0].href                
                check_file   = os.path.isfile(fileName) # check values file already loaded or not                                
                if check_file != True:
                    with open(fileName , 'wb') as f:
                        f.write(req_download['Service']['Document']['File'][0].Contents)                        
                if check_file != True:
                    with ZipFile("{}\{}".format(os.getcwd(),fileName), 'r') as zObject:
                            zObject.extractall(path=str(csv_temp_folder))                                     
                
                f.close()
            manifest_file_path.close()
            
            f1=1
        except Exception as e:
            f1=2
            print(e,"download_manifest_and_zip_files --  ERROR ")
        finally:                    
            return f1
    
    def rename_csv_file(self,):
        """
        Rename the csv file --- remove the file perfix from the file and store in same location
        Args:
        
            request: pull csv file from the path @path is the para.
        Return:
            success flag 
        """

        try:
            #os.remove(zip_temp_folder)
                        
            csv_extract_file_path = Path(str(csv_temp_folder))
            for csv_file in csv_extract_file_path.glob('*.csv'):                
                split_name = str(csv_file).split("\\")
                file_name = (split_name[-1].split('.')[0])
                split_file_name = file_name.split('_')
                join_split_value= ("_".join(split_file_name[1:]))
                time_stamp_split = (split_file_name[3]).split("-")
                total_time_stamp = (time_stamp_split[-1]+split_file_name[-1])

                file_name_identify = join_split_value.split("-")
                file_orginal_name= (file_name_identify[0]+'-'+total_time_stamp)
                
                check_file   = os.path.isfile("{}\{}.csv".format(csv_temp_folder,file_orginal_name)) # check values file already loaded or not                                
                if check_file != True:
                    os.rename("{}\{}.csv".format(csv_temp_folder,file_name), "{}\{}.csv".format(csv_temp_folder,file_orginal_name))
                if check_file == True:                 
                    os.remove("{}\{}.csv".format(csv_temp_folder,file_name))
            f2=1
        except Exception as e:
            f2=2
            print(e,"rename_run_time_flag -- ERROR")

        finally:                      
            return f2
        
    def upload_files_azure_container(self,):

        """
        Connect to Azure account to upload data in storage account
        Args:
        
            request: @param path_dir and file_name.
        Return:
            data file list in storage account in azure 
        """
        try:
            # rename csv file path
            rename_csv_file_path = Path(str(csv_temp_folder))            
            # Azure blob connection
            blog_service_client =  BlobServiceClient.from_connection_string(connection_string)
            # function to load csv data in azure blob container
            
            for rename_file in rename_csv_file_path.glob('*.csv'):                
                ########## Insert Blob ###############
                csv_file_check = Path("{}".format(rename_file))
                df = pd.read_csv(csv_file_check,dtype='unicode')
                check_csv_data = (df.empty)
                check_csv_size = int(df.size)
                
                if check_csv_data != True:
                    splits_val = str(rename_file).split("\\")
                    upper_name = "{}.csv".format((splits_val[-1].split(".")[0])).upper()
                    blob_name  = "{}/{}".format(container_folder_name,upper_name)
                    print(blob_name)
                    blog_client = blog_service_client.get_blob_client(container = container_name,blob=blob_name)
                    with open(rename_file,"rb") as data:
                        blog_client.upload_blob(data)
                if check_csv_size > 7800000 and ANOOP == 1:
                    splits_val = str(rename_file).split("\\")
                    upper_name = "{}.csv".format((splits_val[-1].split(".")[0])).upper()
                    blob_name  = "{}/{}".format(container_folder_name1,upper_name)
                    print(blob_name)
                    blog_client = blog_service_client.get_blob_client(container = container_name,blob=blob_name)
                    with open(rename_file,"rb") as data:
                        blog_client.upload_blob(data)

                ########## Insert Blob ###############           
            f3 =1
        except Exception as e:
            f3=2
            print(e,"upload_cvs_flag -- ERROR")
        finally:                        
            return f3
        
    def manifest_rename_and_end_process(self,):
        """
        Connect to SOAP Request to rename the title 
        Args:
        
            request: static values passes.
        Return:
            return the success msg 
        """
        try:
            ############ Rename ######################
            timeString = datetime.datetime.today().strftime ('%d%m%Y_%H%M%S')
            renameString='MANIFEST_'+timeString+'.MF'      
            ser_rename = ser_request(Document= { 'Field': [{ 'name':'dID','_value_1':dID_manifest},{ 'name':'dDocName','_value_1':dDocName_manifest}, { 'name':'dDocTitle','_value_1':renameString} ]} , IdcService= 'UPDATE_DOCINFO')         
            req_rename = client.service.GenericSoapOperation(Service=ser_rename,webKey='cs')       
            ############ Rename ######################           
            # csv directory path
            print(renameString)
            #delete temp folder           
            shutil.rmtree(mainfest_temp_folder)
            shutil.rmtree(csv_temp_folder)
            os.chdir(r"../")
            shutil.rmtree(zip_temp_folder)

            f4 =1            
            
        except Exception as e:
            f4=2
            print(e,"task_completed_flag -- ERROR")

        finally:                    
            return f4        

if __name__ == '__main__':
    trigger_cls = extract_zip_to_csv()
    f1 = trigger_cls.download_manifest_and_zip_files()
    if f1 == 1:
        f2 = trigger_cls.rename_csv_file() 
    if f2 == 1:
        f3 = trigger_cls.upload_files_azure_container()
    if f3 ==  1:
        f4 = trigger_cls.manifest_rename_and_end_process()
    if f4 ==  1:
        print(" --- Completed all function ---")
         
    