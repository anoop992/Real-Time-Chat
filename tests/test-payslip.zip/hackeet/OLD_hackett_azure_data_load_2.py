"""
Author/File Name   : Xoriant team / hackett_azure_data_load.py
Project Description: Iterate the data from SOPA request and process it load in Azure conatiner 
Deployement method : Job-Scheduler ()
Git repo           :
"""
##### Required Packages - Support ######
from requests import Session
from requests.auth import HTTPBasicAuth
from zeep import Client
from zeep.transports import Transport
from zipfile import ZipFile
#Azure Functions: Install or Update Core Tool
#Basic
import os
import time
import datetime
#Async??
from smart_open import open
from pathlib import Path
import shutil
import pandas as pd
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
import tempfile




# csv directory path 
#extract_csv_dir = Path("C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip")
#zip_dir = Path("C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip")
# removing directory


zip_hackett_Exist = os.path.exists("C:\\Users\\nair_an\\Documents\\anoop_hackett_zip")
csv_hackett_Exist = os.path.exists("C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip")

if csv_hackett_Exist == True:
    shutil.rmtree("C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip")
if zip_hackett_Exist == True:
    shutil.rmtree("C:\\Users\\nair_an\\Documents\\anoop_hackett_zip")



manifest_hackett_Exist = os.path.exists("C:\\Users\\nair_an\\Documents\\anoop_hackett")
zip_hackett_Exist = os.path.exists("C:\\Users\\nair_an\\Documents\\anoop_hackett_zip")
csv_hackett_Exist = os.path.exists("C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip")




if manifest_hackett_Exist != True:
    os.mkdir("C:\\Users\\nair_an\\Documents\\anoop_hackett")
if zip_hackett_Exist != True:
    os.mkdir("C:\\Users\\nair_an\\Documents\\anoop_hackett_zip")
if csv_hackett_Exist != True:
    os.mkdir("C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip")

#Client Session credentials 
session         = Session()
session.auth    = HTTPBasicAuth('BIAETL','bRE26tS8HcTR')
client          = Client('https://eeih-dev1.fa.us2.oraclecloud.com/idcws/GenericSoapPort?WSDL',transport=Transport(session=session))

#Connection string
connect_str     = "DefaultEndpointsProtocol=https;AccountName=oracledatalake;AccountKey=aUljH5hLSKlLGUhK4lwVyJ5p7MOkUQyCRCQNXlKIRN73ciOkjKBmutg0nliTGDzDuSOn6i3Tfbyi+AStCGBRng==;EndpointSuffix=core.windows.net"
ser_request     = client.get_type('ns0:Service')
ser_search      = ser_request(Document= { 'Field': { 'name':'QueryText','_value_1':'dDocTitle <substring> `MANIFEST_13122023_233234.MF`'} } , IdcService= 'GET_SEARCH_RESULTS')
req_search      = client.service.GenericSoapOperation(Service=ser_search,webKey='cs')
var_loop_var    =int(req_search['Service']['Document']['Field'][17]['_value_1'])

if var_loop_var < 1:
    print("No file found as MANIFEST.MF")
    exit()
dID_manifest        =int(req_search['Service']['Document']['ResultSet'][4]['Row'][0]['Field'][0]['_value_1'])
dDocName_manifest   =req_search['Service']['Document']['ResultSet'][4]['Row'][0]['Field'][75]['_value_1']



os.chdir(r"C:\\Users\\nair_an\\Documents\\anoop_hackett")

## Azure data
storage_account_key     = "aUljH5hLSKlLGUhK4lwVyJ5p7MOkUQyCRCQNXlKIRN73ciOkjKBmutg0nliTGDzDuSOn6i3Tfbyi+AStCGBRng=="
storage_account_name    = "oracledatalake"
connection_string       = "DefaultEndpointsProtocol=https;AccountName=oracledatalake;AccountKey=oE0jcds/vXs2a34Jm2+vO8TaukUJIyMPwC8gAYL0JKVjjF8pyFh8c3zv56KtPcWi2NyZ8QEbJa/Q+AStqPcJLA==;EndpointSuffix=core.windows.net"
container_name          = "adfstagedcopytempdata"

#static flag declaration:
downlaod_run_time_flag  = 0
rename_run_time_flag    = 0
upload_cvs_flag         = 0
task_completed_flag     = 0

#folder link
mainfest_folder = 'C:\\Users\\nair_an\\Documents\\anoop_hackett\\MANIFEST.MF'
zip_folder      = "C:\\Users\\nair_an\\Documents\\anoop_hackett_zip\\"
csv_folder      = "C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip"


class extract_zip_to_csv:

    def __init__(self,):        
        self.flag    = 0
    # Connect to SPA - API
    def download_manifest_and_zip_files(self,):

        """
        Connect to azure credentials and download manifest and zip folder
        Args:
            request: Token & URL path 
        Return:
            store mainfest file and zip file in location
        """
        try:
            """
                Downalod the MANIFEST file in local via SOAP request 
            
            """
            
            var_manifest_id =int(req_search['Service']['Document']['ResultSet'][4]['Row'][0]['Field'][0]['_value_1']) # MANIFEST ID
            ser_download    = ser_request(Document= { 'Field': { 'name':'dID','_value_1':+var_manifest_id} } , IdcService= 'GET_FILE')            
            req_download    = client.service.GenericSoapOperation(Service=ser_download,webKey='cs')
            fileName = req_download['Service']['Document']['File'][0].href
            with open(fileName , 'wb') as f:
                f.write(req_download['Service']['Document']['File'][0].Contents)
            f.close()
            """
                Read data from MANIFEST amd pass values to iterate the zip file in local storage

            """
                       
            #manifest_file_path          = open('C:\\Users\\nair_an\\Documents\\anoop_hackett\\MANIFEST.MF', 'r')
            manifest_file_path          = open(mainfest_folder, 'r')
            read_all_line_one_by_one    = manifest_file_path.readlines()
            os.chdir(r"C:\\Users\\nair_an\\Documents\\anoop_hackett_zip") #zip_file_store_path
            for line in read_all_line_one_by_one[1:2]:
                print(line)
                downloadName    = line.split(";")[0] # file name 
                dID             = int(line.split(";")[1]) # file downlaod id
                ser_download = ser_request(Document= { 'Field': { 'name':'dID','_value_1':+dID} } , IdcService= 'GET_FILE')
                req_download = client.service.GenericSoapOperation(Service=ser_download,webKey='cs')
                fileName     = req_download['Service']['Document']['File'][0].href                
                check_file   = os.path.isfile(fileName) # check values file already loaded or not                                
                if check_file != True:
                    with open(fileName , 'wb') as f:                        
                        f.write(req_download['Service']['Document']['File'][0].Contents)
                if check_file != True:
                    with ZipFile("C:\\Users\\nair_an\\Documents\\anoop_hackett_zip\\{}".format(fileName), 'r') as zObject:
                            zObject.extractall(path="C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip")                     
                f.close()
                
                break             
            f1=1
        except Exception as e:
            f1=2
            print(e,"download_manifest_and_zip_files --  ERROR ")
        finally:                    
            return f1
    
    def rename_csv_file(self,):
        """
        Rename the csv file --- remove the file perfix from the file and store in same location
        Args:
        
            request: pull csv file from the path @path is the para.
        Return:
            success flag 
        """

        try:            
            csv_extract_file_path = Path("C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip")
            for csv_file in csv_extract_file_path.glob('*.csv'):
                
                split_name = str(csv_file).split("\\")
                file_name = (split_name[-1].split('.')[0])
                split_file_name = file_name.split('_')
                join_split_value= ("_".join(split_file_name[1:]))
                time_stamp_split = (split_file_name[3]).split("-")
                total_time_stamp = (time_stamp_split[-1]+split_file_name[-1])

                file_name_identify = join_split_value.split("-")
                #file_orginal_name= (file_name_identify[0])
                file_orginal_name= (file_name_identify[0]+'-'+total_time_stamp)
                
                check_file   = os.path.isfile("C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip\\{}.csv".format(file_orginal_name)) # check values file already loaded or not                                
                if check_file != True:
                    os.rename("C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip\\{}.csv".format(file_name), "C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip\\{}.csv".format(file_orginal_name))
                
            f2=1
        except Exception as e:
            f2=2
            print(e,"rename_run_time_flag -- ERROR")

        finally:                      
            return f2
        
    def upload_files_azure_container(self,):

        """
        Connect to Azure account to upload data in storage account
        Args:
        
            request: @param path_dir and file_name.
        Return:
            data file list in storage account in azure 
        """
        try:
            # rename csv file path
            rename_csv_file_path = Path("C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip")            
            # Azure blob connection
            blog_service_client =  BlobServiceClient.from_connection_string(connection_string)
            # function to load csv data in azure blob container
            for rename_file in rename_csv_file_path.glob('*.csv'):                
                ########## Insert Blob ###############
                
                splits_val = str(rename_file).split("\\")
                upper_name = "{}.csv".format((splits_val[-1].split(".")[0])).upper()
                blob_name  = "Ziptest/{}".format(upper_name)
                blog_client = blog_service_client.get_blob_client(container = container_name,blob=blob_name)
                with open(rename_file,"rb") as data:
                    blog_client.upload_blob(data)                
                ########## Insert Blob ###############           
            f3 =1
        except Exception as e:
            f3=2
            print(e,"upload_cvs_flag -- ERROR")
        finally:                        
            return f3
        
    def manifest_rename_and_end_process(self,):
        """
        Connect to SOAP Request to rename the title 
        Args:
        
            request: static values passes.
        Return:
            return the success msg 
        """
        try:
           
            ############ Rename ######################
            timeString = datetime.datetime.today().strftime ('%d%m%Y_%H%M%S')
            renameString='MANIFEST_'+timeString+'.MF'      
            ser_rename = ser_request(Document= { 'Field': [{ 'name':'dID','_value_1':dID_manifest},{ 'name':'dDocName','_value_1':dDocName_manifest}, { 'name':'dDocTitle','_value_1':renameString} ]} , IdcService= 'UPDATE_DOCINFO')         
            req_rename = client.service.GenericSoapOperation(Service=ser_rename,webKey='cs')       
            ############ Rename ######################            
            
            # csv directory path
            print(renameString)
            shutil.rmtree("C:\\Users\\nair_an\\Documents\\anoop_hackett_extract_zip")
            shutil.rmtree("C:\\Users\\nair_an\\Documents\\anoop_hackett_zip")
            shutil.rmtree("C:\\Users\\nair_an\\Documents\\anoop_hackett")             

            f4 =1
        except Exception as e:
            f4=2
            print(e,"task_completed_flag -- ERROR")

        finally:                     
            
            return f4        

if __name__ == '__main__':
    trigger_cls = extract_zip_to_csv()
    f1 = trigger_cls.download_manifest_and_zip_files()
    #flag_end_pt = trigger_cls.upload_files_azure_container()
    if f1 == 1:
        f2 = trigger_cls.rename_csv_file() 
    if f2 == 1:
        f3 = trigger_cls.upload_files_azure_container()
    if f3 ==  1:
        f4 = trigger_cls.manifest_rename_and_end_process()
    if f4 ==  1:
        print(" --- Completed all function ---")
    