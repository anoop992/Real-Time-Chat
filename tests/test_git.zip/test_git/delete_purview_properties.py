"""
Author/File Name   : Xoriant team / sap_purview_ff_script.py
Project Description: Pull data from SAP endpoint and import in Purview entity
Deployement method : Job-Scheduler ()
Git repo           :
"""

##### Required Packages - Support ######
from configparser import ConfigParser
import requests
import json
import pandas as pd
############### Azure packages ######
from azure.identity import ClientSecretCredential
from purviewautomation import PurviewCollections, ServicePrincipalAuthentication

############### atlas ####################

from pyapacheatlas.auth import ServicePrincipalAuthentication
from pyapacheatlas.core import PurviewClient, AtlasEntity, AtlasProcess, TypeCategory
from pyapacheatlas.core.util import GuidTracker
from pyapacheatlas.core.typedef import AtlasAttributeDef, EntityTypeDef, RelationshipTypeDef

# Config -  Setting 

CONFIG_OBJ = ConfigParser()
CONFIG_OBJ.read("./config.ini")

#Global varible declaration

client_id               = CONFIG_OBJ["SAP_TOKEN"]['client_id']
client_secret           = CONFIG_OBJ["SAP_TOKEN"]['client_secret']
grant_type              = 'client_credentials'
resource_url            = CONFIG_OBJ["SAP_TOKEN"]['resource']
tenant_id               = CONFIG_OBJ["SAP_TOKEN"]['tenant_id']
purview_account_name    = "purview-pov-dev"

### Atlas packages to connect to purview

oauth   = ServicePrincipalAuthentication(tenant_id=tenant_id,client_id=client_id,client_secret=client_secret)
client  = PurviewClient(account_name = purview_account_name,authentication=oauth)

### SAP end-pt global variable

stroy_end_point_url     = CONFIG_OBJ["SAP_ENDPOINT"]['stories_end_point']
resource_end_point_url  = CONFIG_OBJ["SAP_ENDPOINT"]['resource_end_point']
unique_token            = CONFIG_OBJ["SAP_TOKEN"]['token']

## Remove enetity name
remove_qualified_name   = ["pyapacheatlas://stories_clutser_data", "pyapacheatlas://story_data"]
remove_entity_type_name = "SAP_API"


############################# DELETE ################################
unit_test_id = 1
stroy_end_point_url = CONFIG_OBJ["SAP_ENDPOINT"]['stories_end_point']
content_end_point_url = CONFIG_OBJ["SAP_ENDPOINT"]['content_end_point']
unique_token = CONFIG_OBJ["SAP_TOKEN"]['token']

headers = {'Ocp-Apim-Subscription-Key': unique_token}
stroy_end_pt_json=(requests.get(stroy_end_point_url, headers=headers))

notebook_path ='_data'


try:  
  
  entities = client.get_entity(
      qualifiedName=["pyapacheatlas://story_data"],
      typeName="SAC_API"
  )

  for entity in entities.get("entities"):
      guids = entity["guid"]
      print(guids)
      delete_response = client.delete_entity(guid=guids)
  

  entities = client.get_entity(
      qualifiedName=["pyapacheatlas://stories_clutser_data"],
      typeName="SAC_API_JOB"
  )

  for entity in entities.get("entities"):
      guids = entity["guid"]
      print(guids)
      delete_response = client.delete_entity(guid=guids)
  
      #print(json.dumps(delete_response, indent=2))
  
except Exception as e:
    pass
    #print('False',e)
finally:
  guid = GuidTracker()
print(222)



df = pd.DataFrame.from_dict(stroy_end_pt_json.json())



type_spark_df = EntityTypeDef(
  name="SAC_API",
  attributeDefs=[
    AtlasAttributeDef(name="format"),
    
  ],
  superTypes = ["DataSet"],
  options = {"schemaElementAttribute":"columns"}
 )

print(11)
type_spark_columns = EntityTypeDef(
  name="SAC_AC_SCHEMA",
  attributeDefs=[
    AtlasAttributeDef(name="data_type"),
    #AtlasAttributeDef(name="createdBy"),
    #AtlasAttributeDef(name="ID"),
    #AtlasAttributeDef(name="changedBy"),
    AtlasAttributeDef(name="created")    
  ],
  superTypes = ["DataSet"],
)
print(12)

type_spark_job = EntityTypeDef(
  name="SAC_API_JOB",
  attributeDefs=[
    AtlasAttributeDef(name="job_type",isOptional=True),
    #AtlasAttributeDef(name="schedule",defaultValue="adHoc")
  ],
  superTypes = ["Process"]
)

print(13)
spark_column_to_df_relationship = RelationshipTypeDef(
  name="SAC_API_COMPOSE",
  relationshipCategory="COMPOSITION",
  endDef1={
          "type": "SAC_API",
          "name": "columns",
          "isContainer": True,
          "cardinality": "SET",
          "isLegacyAttribute": False
      },
  endDef2={
          "type": "SAC_AC_SCHEMA",
          "name": "dataframe",
          "isContainer": False,
          "cardinality": "SINGLE",
          "isLegacyAttribute": False
      }
)

## Work
typedef_results = client.delete_typedefs(
   #entityDefs = [type_spark_columns],
   entityDefs = [type_spark_df, type_spark_columns, type_spark_job ],
   relationshipDefs = [spark_column_to_df_relationship]
   )
# end
print(1234)
exit()


# COMMAND ----------

# No we actually do some databricks work

#############################################################
atlas_input_df = AtlasEntity(
  name="story_data",
  qualified_name = "pyapacheatlas://story_data",
  typeName="SAP_API",
  guid=guid.get_guid(),
  description="SAP-Stories datas",
  attributes = {"name":"test"},
)

#print(atlas_input_df.to_json(minimum=True))
#exit()

# Create a process that represents our notebook and has our input
# dataframe as one of the inputs.
process = AtlasProcess(
  name="Stories_clutser"+notebook_path,
  qualified_name = "pyapacheatlas://stories_clutser"+notebook_path,
  typeName="SAP_API_JOB",
  guid=guid.get_guid(),
  attributes = {"job_type":"stories_sap_data"},
  inputs = [atlas_input_df],
  outputs = [] # No outputs for this demo, but otherwise, repeat what you did you the input dataframe.
)


atlas_input_df_columns = []

k=1
for i in df.index:
    
    
    if i < 3:
        print(i,"###########",df['name'][i])
        temp_column = AtlasEntity(
        name = df['name'][i],
        typeName = "SAP_API_COLUMNS",
        qualified_name = df['openURL'][i],
        guid=guid.get_guid(),
        attributes = {"description":str(df['description'][i]),"displayName":str(df['name'][i]),
                    'data_type':str(df['description'].dtype),"created":str(df['created'][i])},
        #attributes = {"data_type":str("ss")},
        relationshipAttributes = {"dataframe":atlas_input_df.to_json(minimum=True)}
        )
        atlas_input_df_columns.append(temp_column)

# COMMAND ----------

print("###### process ###",process)
print("###### atlas_input_df ###",atlas_input_df)
print("###### atlas_input_df_columns ###",atlas_input_df_columns)
# Prepare all the entities as a batch to be uploaded.
batch = [process, atlas_input_df] + atlas_input_df_columns


client.upload_entities(batch=batch)

#client.delete_entity(batch=batch)







print("completed")
exit()


exit()










############################ DELETE END #########################
sap_end_pt_flag         = 0
sap_end_pt_value_flag   = 1

remove_flag             = 0


unit_test=1
"""
fucntion to call spa-endpoint 
"""
class spa_end_pt_fetch_import_purview:
    
    def __init__(self,):
        self.story_url      = stroy_end_point_url
        self.resource_url   = resource_end_point_url
        self.unique_token   = unique_token
    # Connect to SPA - API
    def end_pt_data(self,):

        """
        Connect to SPA end point and fetch data of stories and resource data
        Args:
            request: Token & URL path 
        Return:
            Json data of stories and resource
        """

        try:
            headers = {'Ocp-Apim-Subscription-Key': self.unique_token}
            stroy_end_pt_json=(requests.get(self.story_url, headers=headers))
            resource_end_pt_json=(requests.get(self.resource_url, headers=headers))
            stories_df = pd.DataFrame.from_dict(stroy_end_pt_json.json())
            #resource_df = pd.DataFrame.from_dict(resource_end_pt_json.json())

            sap_end_pt_flag=1
        except Exception as e:
            # Error Report append
            sap_end_pt_flag=2
            print("ERROR-REPORT---------------> ",e)
        finally:
            #print(sap_end_pt_flag)
            if sap_end_pt_flag !=1:

                # Logger to check the End point connection
                print("Error-Occured while connect to SAP Endpoint")                
            
            return stories_df,sap_end_pt_flag
    
    # Remove the data in entity
    def remove_entity_data_purview(self,entity_ty_name,entity_qulified_name):
        """
        Connect to Purview import new data in entity
        Args:
        
            request: @param entity_ty_name,entity_qulified_name.
        Return:
            remove_flag - First load entity shows msg because no entity was created previous 
        """

        try:
            # invoke the entities to remove
            entities = client.get_entity(qualifiedName=entity_qulified_name,typeName=entity_ty_name)

            # remove all the enetity under SAP_API
            for entity in entities.get("entities"):
                guids = entity["guid"]
                delete_response = client.delete_entity(guid=guids)
            remove_flag = 1

        except Exception as e:
            remove_flag = 2
            print("Entity Created in Purview")

        finally:
            
            return remove_flag
    
    #import sap end pt data in purview entity

    def import_data_purview(self,st_df,resourc_val):

        """
        Create entity and custome properties along with data relation and entity releation 
        Args:
        
            request: @param st_df,resourc_df
        Return:
            logg msg status - return the log msg  
        """
        try:
            # unique id tracker
            guid = GuidTracker()
            
            atlas_input_df_columns = [] # empty list declar to append entity job and colums
            
            #Dataframe enetity
            type_sap_df = EntityTypeDef(name="SAP_API",attributeDefs=[AtlasAttributeDef(name="format"),],
                                          superTypes = ["DataSet"],options = {"schemaElementAttribute":"columns"})
            
            # Custome properties columns
            type_sap_columns = EntityTypeDef(name="SAP_API_COLUMNS",attributeDefs=[AtlasAttributeDef(name="data_type"),
                                                                                     AtlasAttributeDef(name="createdBy"),
                                                                                     AtlasAttributeDef(name="ID"),
                                                                                     AtlasAttributeDef(name="changedBy"),
                                                                                     AtlasAttributeDef(name="created")],
                                                                                     superTypes = ["DataSet"],)
            # Job creation
            type_sap_job = EntityTypeDef(name="SAP_API_JOB",attributeDefs=[AtlasAttributeDef(name="job_type",isOptional=False),
                                                                             AtlasAttributeDef(name="schedule",defaultValue="adHoc")],
                                                                             superTypes = ["Process"])
            
            sap_column_to_df_relationship = RelationshipTypeDef(name="SAP_API_COMPOSE",
                                                                  relationshipCategory="COMPOSITION",
                                                                  endDef1={"type": "SAP_API",
                                                                           "name": "columns",
                                                                           "isContainer": True,
                                                                           "cardinality": "SET",
                                                                           "isLegacyAttribute": False},
                                                                           endDef2={"type": "SAP_API_COLUMNS",
                                                                                    "name": "dataframe",
                                                                                    "isContainer": False,
                                                                                    "cardinality": "SINGLE",
                                                                                    "isLegacyAttribute": False})
            #Upload all the jobs in SAP_API entity
            typedef_results = client.upload_typedefs(entityDefs =[type_sap_df, 
                                                                  type_sap_columns, 
                                                                  type_sap_job ],
                                                                  relationshipDefs = [sap_column_to_df_relationship],
                                                                  force_update=True)
            
            #Upload all the jobs in SAP_API entity
            atlas_input_df = AtlasEntity(name="story_data",
                                         qualified_name = remove_qualified_name[1],
                                         typeName="SAP_API",
                                         guid=guid.get_guid(),
                                         description="SAP-Stories datas",
                                         attributes = {"name":"test"},)
            
            process = AtlasProcess(name="Stories_clutser_data",
                                   qualified_name = remove_qualified_name[0],
                                   typeName="SAP_API_JOB",
                                   guid=guid.get_guid(),
                                   attributes = {"job_type":"stories_sap_data"},
                                   inputs = [atlas_input_df],outputs = [])
            
            #import all the rows of columns in SPA_API entity
            for i in st_df.index:
                if unit_test==1:                    
                    temp_column = AtlasEntity(name = st_df['name'][i],
                                              typeName = "SAP_API_COLUMNS",
                                              qualified_name = st_df['openURL'][i],
                                              guid=guid.get_guid(),
                                              attributes = {"description":str(st_df['description']),
                                                            "displayName":str(st_df['name'][i]),
                                                            'data_type':str(st_df['description'].dtype),
                                                            "ID":str(st_df['id'][i]),
                                                            "created":str(st_df['created'][i]),
                                                            "createdBy":str(st_df['createdBy'][i])},
                                                            relationshipAttributes = {"dataframe":atlas_input_df.to_json(minimum=True)})
                atlas_input_df_columns.append(temp_column) # upload all the columns rows in the empty list

            batch = [process, atlas_input_df] + atlas_input_df_columns ## List of

            client.upload_entities(batch=batch)

            

        except Exception as e:
            print(e)
        finally:
            print("completed")


### Trigger the Script to Run ####:

if __name__ == '__main__':
    trigger_cls = spa_end_pt_fetch_import_purview()
    stor_data_df,flag_end_pt = trigger_cls.end_pt_data()
    

    #call a function to remove columns entity
    if len(stor_data_df) !=0:
        remove_flag_data = trigger_cls.remove_entity_data_purview(remove_entity_type_name,remove_qualified_name)

    #import data in entity
    if len(stor_data_df) !=0:
        resour_data_df=0
        import_status = trigger_cls.import_data_purview(stor_data_df,resour_data_df)
        



